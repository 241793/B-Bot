"""
模拟QQ客户端
连接到反向WebSocket服务器以接收机器人框架发送的消息
"""
import asyncio
import websockets
import json
import uuid
from datetime import datetime
import os


class QQClient:
    """
    模拟QQ客户端，连接到反向WebSocket服务器接收消息
    """
    
    def __init__(self, ws_url: str = None):
        # 使用环境变量或默认端口
        reverse_ws_port = int(os.getenv('REVERSE_WS_PORT', '8081'))
        self.ws_url = ws_url or f"ws://localhost:{reverse_ws_port}"
        self.websocket = None
        self.is_connected = False
    
    async def connect(self):
        """
        连接到反向WebSocket服务器
        """
        try:
            print(f"正在连接到反向WebSocket服务器 {self.ws_url}...")
            self.websocket = await websockets.connect(self.ws_url)
            self.is_connected = True
            print("✅ 成功连接到反向WebSocket服务器！现在可以接收机器人框架发送的消息。")
            
            # 启动消息接收循环
            await self.receive_messages()
            
        except Exception as e:
            print(f"❌ 连接反向WebSocket服务器失败: {e}")
    
    async def receive_messages(self):
        """
        接收来自服务器的消息
        """
        try:
            async for message in self.websocket:
                try:
                    data = json.loads(message)
                    print(f"📱 [{datetime.now().strftime('%H:%M:%S')}] 收到消息: {data}")
                    
                    # 模拟处理接收到的消息
                    if data.get("action") == "send_private_msg":
                        user_id = data["params"]["user_id"]
                        msg_content = data["params"]["message"]
                        print(f"👤 私聊消息 -> 用户{user_id}: {msg_content}")
                    elif data.get("action") == "send_group_msg":
                        group_id = data["params"]["group_id"]
                        msg_content = data["params"]["message"]
                        print(f"👥 群聊消息 -> 群{group_id}: {msg_content}")
                    else:
                        print(f"💬 通用消息: {msg_content}")
                        
                except json.JSONDecodeError:
                    print(f"💬 [{datetime.now().strftime('%H:%M:%S')}] 收到非JSON消息: {message}")
        except websockets.exceptions.ConnectionClosed:
            print("WebSocket连接已关闭")
            self.is_connected = False
        except Exception as e:
            print(f"接收消息时出错: {e}")
            self.is_connected = False
    
    async def send_test_message_to_framework(self):
        """
        发送测试消息到框架（通过另一个连接到8080的客户端）
        这个方法仅用于演示，实际使用中QQ会通过其自己的WebSocket连接发送消息
        """
        try:
            # 获取框架WebSocket端口
            ws_port = int(os.getenv('WS_PORT', '8080'))
            # 连接到框架的WebSocket服务器端口8080发送消息
            async with websockets.connect(f"ws://localhost:{ws_port}") as ws_client:
                # 发送测试消息
                test_msg = {
                    "id": str(uuid.uuid4()),
                    "type": "message",
                    "content": "你好机器人",
                    "user_id": "qq_user_12345",
                    "group_id": "qq_group_67890",
                    "timestamp": datetime.now().isoformat(),
                    "raw_message": "你好机器人"
                }
                
                await ws_client.send(json.dumps(test_msg, ensure_ascii=False))
                print(f"📤 已发送测试消息到框架: {test_msg['content']}")
                
                # 等待一段时间查看回复
                await asyncio.sleep(2)
                
        except Exception as e:
            print(f"发送测试消息失败: {e}")


async def main():
    """
    主函数
    """
    print("🤖 模拟QQ客户端启动")
    print("这个客户端将连接到反向WebSocket服务器 (端口8081) 来接收机器人框架发送的消息")
    print("-" * 60)
    
    # 创建QQ客户端并连接到反向WebSocket服务器
    qq_client = QQClient()
    
    # 运行接收消息的任务
    receive_task = asyncio.create_task(qq_client.connect())
    
    # 同时发送一个测试消息到框架
    await asyncio.sleep(2)  # 等待连接建立
    await qq_client.send_test_message_to_framework()
    
    try:
        # 保持运行
        await receive_task
    except KeyboardInterrupt:
        print("\n👋 客户端已停止")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n程序被用户中断")