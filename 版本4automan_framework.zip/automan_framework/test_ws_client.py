"""
WebSocket测试客户端
用于连接机器人框架并发送测试消息
"""
import asyncio
import websockets
import json
import uuid
from datetime import datetime


class WSTestClient:
    """
    WebSocket测试客户端
    """
    
    def __init__(self, ws_url: str = "ws://localhost:8080"):
        self.ws_url = ws_url
        self.websocket = None
    
    async def connect(self):
        """
        连接到WebSocket服务器
        """
        try:
            print(f"正在连接到 {self.ws_url}...")
            self.websocket = await websockets.connect(self.ws_url)
            print("WebSocket连接成功！")
            
            # 启动消息接收协程
            asyncio.create_task(self.receive_messages())
            
            return True
        except Exception as e:
            print(f"WebSocket连接失败: {e}")
            return False
    
    async def receive_messages(self):
        """
        接收来自服务器的消息
        """
        try:
            async for message in self.websocket:
                try:
                    data = json.loads(message)
                    print(f"[接收] {datetime.now().strftime('%H:%M:%S')} - {data}")
                except json.JSONDecodeError:
                    print(f"[接收] {datetime.now().strftime('%H:%M:%S')} - {message}")
        except websockets.exceptions.ConnectionClosed:
            print("WebSocket连接已关闭")
        except Exception as e:
            print(f"接收消息时出错: {e}")
    
    async def send_message(self, message_type: str, content: str, user_id: str = "test_user", group_id: str = "test_group"):
        """
        发送消息到服务器
        """
        message = {
            "id": str(uuid.uuid4()),
            "type": message_type,
            "content": content,
            "user_id": user_id,
            "group_id": group_id,
            "timestamp": datetime.now().isoformat(),
            "raw_message": content
        }
        
        try:
            await self.websocket.send(json.dumps(message, ensure_ascii=False))
            print(f"[发送] {datetime.now().strftime('%H:%M:%S')} - {message}")
            return True
        except Exception as e:
            print(f"发送消息失败: {e}")
            return False
    
    async def send_test_messages(self):
        """
        发送一系列测试消息
        """
        # while True:
            # content = input("请输入要发送的消息：")
            # await self.send_message("message", content)
            # print("\n测试消息发送完成，保持连接30秒以接收回复...")
            # await asyncio.sleep(5)
            #
            #
            # if content == "exit":
            #     break

        test_messages = [
            ("message", "你好"),
            ("message", "hello"),
            ("message", "hi"),
            ("message", "复读 这是一条复读测试消息"),
            ("message", "测试插件功能"),
            ("message", "帮助"),
            ("message", "状态"),
        ]

        for msg_type, content in test_messages:
            await self.send_message(msg_type, content)
            await asyncio.sleep(1)  # 等待1秒再发送下一条
    
    async def close(self):
        """
        关闭连接
        """
        if self.websocket:
            await self.websocket.close()
            print("WebSocket连接已关闭")


async def main():
    """
    主函数
    """
    # 创建测试客户端
    client = WSTestClient("ws://localhost:8080")  # 使用默认端口，您可以根据需要修改
    
    # 连接到服务器
    if await client.connect():
        print("\n开始发送测试消息...")
        await client.send_test_messages()
        
        print("\n测试消息发送完成，保持连接30秒以接收回复...")
        await asyncio.sleep(30)
        
        await client.close()
    else:
        print("无法连接到WebSocket服务器")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n测试被用户中断")