import asyncio
import websockets
import json


async def send_detailed_llo_onebot_message():
    """
    发送详细LLOneBot格式的消息，包含完整的原始消息数据
    """
    # 使用您提供的详细日志中的消息格式
    message = {
        'self_id': 3599198670,
        'user_id': 2417934243,
        'time': 1766730551,
        'message_id': 1399656344,
        'message_seq': 9609,
        'message_type': 'private',
        'sender': {
            'user_id': 2417934243,
            'nickname': '小白',
            'card': ''
        },
        'raw_message': '你好',
        'font': 14,
        'sub_type': 'friend',
        'message': '你好',
        'message_format': 'string',
        'post_type': 'message',
        'raw': {
            'msgId': '7588049938385775613',
            'msgRandom': '782150323',
            'msgSeq': '9609',
            'cntSeq': '0',
            'chatType': 1,
            'msgType': 2,
            'subMsgType': 1,
            'sendType': 0,
            'senderUid': 'u_TtdgMVtHmllAjbGHhem03g',
            'peerUid': 'u_TtdgMVtHmllAjbGHhem03g',
            'channelId': '',
            'guildId': '',
            'guildCode': '0',
            'fromUid': '0',
            'fromAppid': '0',
            'msgTime': '1766730551',
            'msgMeta': {},
            'sendStatus': 2,
            'sendRemarkName': '',
            'sendMemberName': '',
            'sendNickName': '',
            'guildName': '',
            'channelName': '',
            'elements': [
                {
                    'elementType': 1,
                    'elementId': '7588049938385775612',
                    'elementGroupId': 0,
                    'extBufForUI': {},
                    'textElement': {
                        'content': '你好',
                        'atType': 0,
                        'atUid': '0',
                        'atTinyId': '0',
                        'atNtUid': '',
                        'subElementType': 0,
                        'atChannelId': '0',
                        'linkInfo': None,
                        'atRoleId': '0',
                        'atRoleColor': 0,
                        'atRoleName': '',
                        'needNotify': 0
                    },
                    'faceElement': None,
                    'marketFaceElement': None,
                    'replyElement': None,
                    'picElement': None,
                    'pttElement': None,
                    'videoElement': None,
                    'grayTipElement': None,
                    'arkElement': None,
                    'fileElement': None,
                    'liveGiftElement': None,
                    'markdownElement': None,
                    'structLongMsgElement': None,
                    'multiForwardMsgElement': None,
                    'giphyElement': None,
                    'walletElement': None,
                    'inlineKeyboardElement': None,
                    'textGiftElement': None,
                    'calendarElement': None,
                    'yoloGameResultElement': None,
                    'avRecordElement': None,
                    'structMsgElement': None,
                    'faceBubbleElement': None,
                    'shareLocationElement': None,
                    'tofuRecordElement': None,
                    'taskTopMsgElement': None,
                    'recommendedMsgElement': None,
                    'actionBarElement': None,
                    'prologueMsgElement': None,
                    'forwardMsgElement': None
                }
            ],
            'records': [],
            'emojiLikesList': [],
            'commentCnt': '0',
            'directMsgFlag': 0,
            'directMsgMembers': [],
            'peerName': '',
            'freqLimitInfo': None,
            'editable': False,
            'avatarMeta': '',
            'avatarPendant': '',
            'feedId': '',
            'roleId': '0',
            'timeStamp': '0',
            'clientIdentityInfo': None,
            'isImportMsg': False,
            'atType': 0,
            'roleType': 0,
            'fromChannelRoleInfo': {'roleId': '0', 'name': '', 'color': 0},
            'fromGuildRoleInfo': {'roleId': '0', 'name': '', 'color': 0},
            'levelRoleInfo': {'roleId': '0', 'name': '', 'color': 0},
            'recallTime': '0',
            'isOnlineMsg': True,
            'generalFlags': {},
            'clientSeq': '56279',
            'fileGroupSize': None,
            'foldingInfo': None,
            'multiTransInfo': None,
            'senderUin': '2417934243',
            'peerUin': '2417934243',
            'msgAttrs': {},
            'anonymousExtInfo': None,
            'nameType': 0,
            'avatarFlag': 0,
            'extInfoForUI': None,
            'personalMedal': None,
            'categoryManage': 0,
            'msgEventInfo': None,
            'sourceType': 1
        }
    }
    
    try:
        async with websockets.connect('ws://127.0.0.1:8084') as websocket:
            await websocket.send(json.dumps(message, ensure_ascii=False))
            print(f"已发送详细LLOneBot格式消息到框架: {message['message']}")
            print(f"消息来自用户: {message['user_id']}, 机器人: {message['self_id']}")
            
            # 等待一段时间以查看响应
            await asyncio.sleep(5)
    except Exception as e:
        print(f"连接失败: {e}")


if __name__ == "__main__":
    asyncio.run(send_detailed_llo_onebot_message())