"""
Web UI应用
提供可视化面板，用于配置和监控机器人框架
"""
import asyncio
import inspect
import json
from datetime import datetime
from typing import Dict, Any
from flask import Flask, render_template, request, jsonify, send_from_directory, session, redirect, url_for, flash
import os
import psutil
from utils.logger import get_logger, log_queue
from rule_engine.rule_engine import Rule
from web_ui.views.schedule_views import schedule_bp, init_app as init_schedule_app
from utils import dependency_manager, user_manager
from config import config


class WebUI:
    """
    Web UI类，提供可视化面板功能
    """
    
    def __init__(self, middleware, plugin_manager, rule_engine, bucket_manager, host: str = "0.0.0.0", port: int = 5000):
        """
        初始化Web UI
        :param middleware: 中间件实例
        :param plugin_manager: 插件管理器实例
        :param rule_engine: 规则引擎实例
        :param bucket_manager: 桶管理器实例
        :param host: 监听主机
        :param port: 监听端口
        """
        self.middleware = middleware
        self.plugin_manager = plugin_manager
        self.rule_engine = rule_engine
        self.bucket_manager = bucket_manager
        self.host = host
        self.port = port
        self.logger = get_logger("web_ui")
        
        # 初始化Flask应用
        self.app = Flask(__name__)
        self.app.config['SECRET_KEY'] = os.urandom(24)
        
        # 设置模板和静态文件目录
        templates_dir = os.path.join(os.path.dirname(__file__), 'templates')
        static_dir = os.path.join(os.path.dirname(__file__), 'static')
        
        if not os.path.exists(templates_dir):
            os.makedirs(templates_dir)
        if not os.path.exists(static_dir):
            os.makedirs(static_dir)
        
        # 注册蓝图
        init_schedule_app(self.middleware)
        self.app.register_blueprint(schedule_bp)

        # 注册路由
        self._register_auth_routes()
        self._register_routes()
        self._register_system_routes()
        self._register_dependency_routes()

    def _register_auth_routes(self):
        """注册认证相关的路由和请求钩子"""

        @self.app.before_request
        async def before_request_func():
            # 检查是否已存在用户，用于判断是否为首次运行
            is_first_run = not await user_manager.user_exists(self.bucket_manager)
            
            # 允许访问的端点列表
            allowed_endpoints = ['login', 'register', 'static']

            # 如果是首次运行，且访问的不是注册页，则重定向到注册页
            if is_first_run and request.endpoint not in allowed_endpoints:
                return redirect(url_for('register'))
            
            # 如果不是首次运行，且用户未登录，且访问的不是允许的页面，则重定向到登录页
            if not is_first_run and 'user_id' not in session and request.endpoint not in allowed_endpoints:
                return redirect(url_for('login'))

        @self.app.route('/login', methods=['GET', 'POST'])
        async def login():
            if request.method == 'POST':
                username = request.form['username']
                password = request.form['password']
                if await user_manager.verify_user(self.bucket_manager, username, password):
                    session['user_id'] = username
                    return redirect(url_for('index'))
                else:
                    flash('用户名或密码错误', 'danger')
            return render_template('login.html')

        @self.app.route('/register', methods=['GET', 'POST'])
        async def register():
            if await user_manager.user_exists(self.bucket_manager):
                return redirect(url_for('login'))

            if request.method == 'POST':
                username = request.form['username']
                password = request.form['password']
                confirm_password = request.form['confirm_password']

                if password != confirm_password:
                    flash('两次输入的密码不一致', 'warning')
                    return render_template('register.html')

                if await user_manager.create_user(self.bucket_manager, username, password):
                    session['user_id'] = username
                    flash('注册成功！', 'success')
                    return redirect(url_for('index'))
                else:
                    flash('创建用户失败', 'danger')

            return render_template('register.html')

        @self.app.route('/logout')
        def logout():
            session.pop('user_id', None)
            return redirect(url_for('login'))

    def _register_dependency_routes(self):
        """
        注册依赖管理相关的路由
        """
        @self.app.route('/api/dependencies', methods=['GET'])
        def api_list_dependencies():
            """获取所有已安装的依赖包"""
            result = dependency_manager.list_packages()
            if result["success"]:
                return jsonify(result)
            return jsonify(result), 500

        @self.app.route('/api/dependencies/install', methods=['POST'])
        def api_install_dependency():
            """安装一个新的依赖包"""
            data = request.get_json()
            if not data or 'package_name' not in data:
                return jsonify({"success": False, "output": "请求体中缺少 'package_name' 字段。"}), 400
            
            package_name = data.get('package_name')
            index_url = data.get('index_url') # 可选的依赖源
            
            result = dependency_manager.install_package(package_name, index_url)
            if result["success"]:
                return jsonify(result)
            return jsonify(result), 500

        @self.app.route('/api/dependencies/uninstall', methods=['POST'])
        def api_uninstall_dependency():
            """卸载一个依赖包"""
            data = request.get_json()
            if not data or 'package_name' not in data:
                return jsonify({"success": False, "output": "请求体中缺少 'package_name' 字段。"}), 400

            package_name = data.get('package_name')
            result = dependency_manager.uninstall_package(package_name)
            if result["success"]:
                return jsonify(result)
            return jsonify(result), 500
            
    def _register_system_routes(self):
        """
        注册系统配置相关的路由
        """
        @self.app.route('/api/system/stats', methods=['GET'])
        def api_get_system_stats():
            """获取系统CPU和内存使用率"""
            try:
                cpu_percent = psutil.cpu_percent(interval=0.1)
                memory_info = psutil.virtual_memory()
                stats = {
                    "cpu_percent": cpu_percent,
                    "memory_percent": memory_info.percent,
                }
                return jsonify(stats)
            except Exception as e:
                self.logger.error(f"获取系统状态时出错: {e}")
                return jsonify({"error": str(e)}), 500

        @self.app.route('/api/system/config', methods=['GET'])
        async def api_get_system_config():
            """获取所有系统配置"""
            try:
                keys = [
                    "admin_list", "version_number", "version_content",
                    "group_reply_enabled", "group_blacklist", "private_reply_enabled",
                    "reverse_ws_port"
                ]
                defaults = {
                    "admin_list": [], "version_number": "1.0.0", "version_content": "",
                    "group_reply_enabled": True, "group_blacklist": [], "private_reply_enabled": True,
                    "reverse_ws_port": config.reverse_ws_port
                }
                
                config_data = {}
                for key in keys:
                    config_data[key] = await self.bucket_manager.get("system", key, defaults.get(key))
                
                return jsonify(config_data)
            except Exception as e:
                self.logger.error(f"获取系统配置时出错: {e}")
                return jsonify({"error": str(e)}), 500

        @self.app.route('/api/system/config', methods=['POST'])
        async def api_save_system_config():
            """保存所有系统配置"""
            try:
                data = request.get_json()
                if not data:
                    return jsonify({"success": False, "message": "无效的请求数据"}), 400

                # 对特定字段进行类型转换和处理
                if 'admin_list' in data and isinstance(data['admin_list'], str):
                    data['admin_list'] = [admin.strip() for admin in data['admin_list'].split('&') if admin.strip()]
                
                if 'group_blacklist' in data and isinstance(data['group_blacklist'], str):
                    data['group_blacklist'] = [group.strip() for group in data['group_blacklist'].split('&') if group.strip()]

                if 'reverse_ws_port' in data:
                    try:
                        data['reverse_ws_port'] = int(data['reverse_ws_port'])
                    except (ValueError, TypeError):
                        return jsonify({"success": False, "message": "反向WebSocket端口必须是一个有效的数字"}), 400

                for key, value in data.items():
                    await self.bucket_manager.set("system", key, value)
                
                self.logger.info("系统配置已通过Web UI更新")
                return jsonify({"success": True, "message": "系统配置保存成功！"})
            
            except Exception as e:
                self.logger.error(f"保存系统配置时出错: {e}")
                return jsonify({"success": False, "message": str(e)}), 500

    def _register_routes(self):
        """
        注册路由
        """
        @self.app.route('/')
        def index():
            return self._render_dashboard()
        
        @self.app.route('/dashboard')
        def dashboard():
            return self._render_dashboard()
        
        @self.app.route('/api/status')
        def api_status():
            return self._api_get_status()
        
        @self.app.route('/api/chat', methods=['POST'])
        async def api_chat():
            return await self._api_chat()

        @self.app.route('/api/adapters')
        def api_adapters():
            return self._api_get_adapters()
        
        @self.app.route('/api/plugins')
        def api_plugins():
            return self._api_get_plugins()
        
        @self.app.route('/api/plugins/<plugin_name>', methods=['DELETE'])
        async def api_delete_plugin(plugin_name):
            return await self._api_delete_plugin(plugin_name)
        
        @self.app.route('/api/plugins/<plugin_name>/load', methods=['POST'])
        async def api_load_plugin(plugin_name):
            return await self._api_load_plugin(plugin_name)
        
        @self.app.route('/api/plugins/<plugin_name>/unload', methods=['POST'])
        async def api_unload_plugin(plugin_name):
            return await self._api_unload_plugin(plugin_name)
        
        @self.app.route('/api/plugins/<plugin_name>/reload', methods=['POST'])
        async def api_reload_plugin(plugin_name):
            return await self._api_reload_plugin(plugin_name)
        
        @self.app.route('/api/plugins/scan', methods=['GET'])
        def api_scan_plugins():
            return self._api_scan_plugins()
        
        @self.app.route('/api/plugins/<plugin_name>/enable', methods=['POST'])
        async def api_enable_plugin(plugin_name):
            return await self._api_enable_plugin(plugin_name)
        
        @self.app.route('/api/plugins/<plugin_name>/disable', methods=['POST'])
        async def api_disable_plugin(plugin_name):
            return await self._api_disable_plugin(plugin_name)
        
        @self.app.route('/api/rules', methods=['GET'])
        def api_rules():
            return self._api_get_rules()

        @self.app.route('/api/rules', methods=['POST'])
        async def api_add_rule():
            return await self._api_add_rule()

        @self.app.route('/api/rules/<rule_name>', methods=['DELETE'])
        async def api_delete_rule(rule_name):
            return await self._api_delete_rule(rule_name)
        
        @self.app.route('/api/rules/update/<rule_name>', methods=['POST'])
        async def api_update_rule(rule_name):
            return await self._api_update_rule(rule_name)
        
        @self.app.route('/api/buckets', methods=['GET'])
        async def api_buckets():
            return await self._api_get_buckets()

        @self.app.route('/api/buckets', methods=['POST'])
        async def api_create_bucket():
            return await self._api_create_bucket()

        @self.app.route('/api/buckets/<bucket_name>')
        async def api_bucket_data(bucket_name):
            return await self._api_get_bucket_data(bucket_name)

        @self.app.route('/api/buckets/<bucket_name>/data', methods=['POST'])
        async def api_update_bucket_data(bucket_name):
            return await self._api_update_bucket_data(bucket_name)

        @self.app.route('/api/buckets/<bucket_name>/data/<key>', methods=['DELETE'])
        async def api_delete_bucket_data(bucket_name, key):
            return await self._api_delete_bucket_data(bucket_name, key)
        
        @self.app.route('/api/logs')
        def api_logs():
            return self._api_get_logs()
            
        @self.app.route('/api/logs/clear', methods=['POST'])
        def api_clear_logs():
            return self._api_clear_logs()
        
        @self.app.route('/api/plugins/<plugin_name>/content')
        def api_get_plugin_content(plugin_name):
            return self._api_get_plugin_content(plugin_name)
        
        @self.app.route('/api/plugins/<plugin_name>/content', methods=['POST'])
        async def api_save_plugin_content(plugin_name):
            return await self._api_save_plugin_content(plugin_name)
        
        @self.app.route('/api/adapters/config', methods=['GET'])
        def api_get_adapter_config():
            return self._api_get_adapter_config()
        
        @self.app.route('/api/adapters/config', methods=['POST'])
        def api_save_adapter_config():
            return self._api_save_adapter_config()
        
        @self.app.route('/api/plugins/create', methods=['POST'])
        def api_create_plugin():
            return self._api_create_plugin()
    
    def _render_dashboard(self):
        """
        渲染仪表板页面
        """
        try:
            templates_dir = os.path.join(os.path.dirname(__file__), 'templates')
            dashboard_path = os.path.join(templates_dir, 'dashboard.html')
            
            if os.path.exists(dashboard_path):
                return render_template('dashboard.html')
            else:
                return jsonify({"error": "Dashboard template not found"}), 404
        except Exception as e:
            self.logger.error(f"渲染仪表板时发生错误: {e}")
            return jsonify({"error": str(e)}), 500
    
    async def _api_chat(self):
        """
        API: 处理来自Web UI的聊天消息
        """
        try:
            data = request.get_json()
            if not data or 'message' not in data:
                return jsonify({"reply": "无效的请求"}), 400

            message_text = data['message']
            user_id = session.get('user_id', 'web_user')

            # 构造一个模拟的、符合框架要求的消息对象
            message = {
                'user_id': user_id,
                'message': message_text,
                'content': message_text,  # 确保 content 字段存在
                'message_type': 'private',
                'source': 'web_ui',
                'platform': 'web_ui'  # 定义一个虚拟平台
            }

            self.logger.info(f"Web chat received message from {user_id}: {message_text}")

            # 直接遍历消息处理器来获取响应，而不是调用 process_message
            response_content = None
            for handler in self.middleware.message_handlers:
                try:
                    # 使用 inspect 模块检查处理器函数需要多少参数
                    sig = inspect.signature(handler)
                    num_params = len(sig.parameters)
                    
                    args = [message]
                    if num_params > 1:
                        # 如果处理器需要多个参数，我们假设第二个是中间件实例
                        args.append(self.middleware)

                    # 调用处理器
                    result = await handler(*args) if asyncio.iscoroutinefunction(handler) else handler(*args)

                    # 如果处理器返回了有效结果，则捕获回复内容并中断循环
                    if result and isinstance(result, dict) and 'content' in result:
                        response_content = result['content']
                        self.logger.info(f"Web chat got reply from handler '{getattr(handler, '__module__', 'unknown')}': {response_content}")
                        break
                except Exception as e:
                    self.logger.error(f"Error in handler {getattr(handler, '__module__', 'unknown')} for web chat: {e}", exc_info=True)

            # 根据是否获得回复来返回结果
            if response_content:
                return jsonify({"reply": response_content})
            else:
                return jsonify({"reply": "我暂时不知道该如何回答。"})

        except Exception as e:
            self.logger.error(f"处理Web聊天消息时发生严重错误: {e}", exc_info=True)
            return jsonify({"reply": f"处理消息时发生内部错误: {e}"}), 500

    def _api_get_status(self):
        """
        API: 获取框架状态
        """
        try:
            status = {
                "status": "running",
                "plugins_loaded": len(self.plugin_manager.plugins),
                "rules_loaded": len(self.rule_engine.rules),
                "buckets_count": len(self.bucket_manager.buckets),
                "adapters_count": len(self.middleware.adapters)
            }
            return jsonify(status)
        except Exception as e:
            self.logger.error(f"获取状态时发生错误: {e}")
            return jsonify({"error": str(e)}), 500
    
    def _api_get_adapters(self):
        """
        API: 获取适配器状态
        """
        try:
            adapters_info = {}
            for name, adapter in self.middleware.adapters.items():
                # 提取适配器的配置信息
                adapter_config = {}
                if hasattr(adapter, 'host') and hasattr(adapter, 'port'):
                    adapter_config['host'] = adapter.host
                    adapter_config['port'] = adapter.port
                
                # 对于 WebSocketClientAdapter，可能还需要其他信息
                if 'ws_client' in name and hasattr(adapter, 'url'):
                    adapter_config['url'] = adapter.url

                adapters_info[name] = {
                    "name": name,
                    "connected": getattr(adapter, 'is_running', False),
                    "type": type(adapter).__name__,
                    "config": adapter_config
                }
            return jsonify(adapters_info)
        except Exception as e:
            self.logger.error(f"获取适配器状态时发生错误: {e}")
            return jsonify({"error": str(e)}), 500
    
    def _api_get_plugins(self):
        """
        API: 获取插件列表
        """
        try:
            plugins_data = {}
            all_plugins = self.plugin_manager.get_all_plugins()
            for name, plugin in all_plugins.items():
                plugins_data[name] = {
                    "name": plugin.name,
                    "description": plugin.description,
                    "version": plugin.version,
                    "author": plugin.author,
                    "rules_count": len(plugin.rules),
                    "is_loaded": plugin.is_loaded,
                    "enabled": self.plugin_manager.is_plugin_enabled(name)
                }
            return jsonify(plugins_data)
        except Exception as e:
            self.logger.error(f"获取插件列表时发生错误: {e}")
            return jsonify({"error": str(e)}), 500
    
    async def _api_delete_plugin(self, plugin_name: str):
        """
        API: 删除插件
        """
        try:
            await self.plugin_manager.unload_plugin(plugin_name)
            
            plugin_file = os.path.join(self.plugin_manager.plugins_dir, f"{plugin_name}.py")
            if os.path.exists(plugin_file):
                os.remove(plugin_file)
                return jsonify({"success": True, "message": f"插件 {plugin_name} 已删除"})
            else:
                return jsonify({"success": False, "message": "插件文件未找到"}), 404
        except Exception as e:
            self.logger.error(f"删除插件 {plugin_name} 时发生错误: {e}")
            return jsonify({"error": str(e)}), 500
            
    def _api_scan_plugins(self):
        """
        API: 扫描插件目录
        """
        try:
            plugin_files = [f[:-3] for f in os.listdir(self.plugin_manager.plugins_dir) if f.endswith(".py") and not f.startswith("__")]
            return jsonify(plugin_files)
        except Exception as e:
            self.logger.error(f"扫描插件时发生错误: {e}")
            return jsonify({"error": str(e)}), 500
    
    async def _api_load_plugin(self, plugin_name: str):
        """
        API: 加载插件
        """
        try:
            success = await self.plugin_manager.load_plugin(plugin_name)
            if success:
                return jsonify({"success": True, "message": f"插件 {plugin_name} 加载成功"})
            else:
                return jsonify({"success": False, "message": f"插件 {plugin_name} 加载失败"}), 400
        except Exception as e:
            self.logger.error(f"加载插件 {plugin_name} 时发生错误: {e}")
            return jsonify({"error": str(e)}), 500
    
    async def _api_unload_plugin(self, plugin_name: str):
        """
        API: 卸载插件
        """
        try:
            success = await self.plugin_manager.unload_plugin(plugin_name)
            if success:
                return jsonify({"success": True, "message": f"插件 {plugin_name} 卸载成功"})
            else:
                return jsonify({"success": False, "message": f"插件 {plugin_name} 卸载失败"}), 400
        except Exception as e:
            self.logger.error(f"卸载插件 {plugin_name} 时发生错误: {e}")
            return jsonify({"error": str(e)}), 500
    
    async def _api_reload_plugin(self, plugin_name: str):
        """
        API: 重新加载插件
        """
        try:
            success = await self.plugin_manager.reload_plugin(plugin_name)
            if success:
                return jsonify({"success": True, "message": f"插件 {plugin_name} 重新加载成功"})
            else:
                return jsonify({"success": False, "message": f"插件 {plugin_name} 重新加载失败"}), 400
        except Exception as e:
            self.logger.error(f"重新加载插件 {plugin_name} 时发生错误: {e}")
            return jsonify({"error": str(e)}), 500
    
    async def _api_enable_plugin(self, plugin_name: str):
        """
        API: 启用插件
        """
        try:
            success = await self.plugin_manager.enable_plugin(plugin_name)
            if success:
                return jsonify({"success": True, "message": f"插件 {plugin_name} 启用成功"})
            else:
                return jsonify({"success": False, "message": f"插件 {plugin_name} 启用失败"}), 400
        except Exception as e:
            self.logger.error(f"启用插件 {plugin_name} 时发生错误: {e}")
            return jsonify({"error": str(e)}), 500
    
    async def _api_disable_plugin(self, plugin_name: str):
        """
        API: 禁用插件
        """
        try:
            success = await self.plugin_manager.disable_plugin(plugin_name)
            if success:
                return jsonify({"success": True, "message": f"插件 {plugin_name} 禁用成功"})
            else:
                return jsonify({"success": False, "message": f"插件 {plugin_name} 禁用失败"}), 400
        except Exception as e:
            self.logger.error(f"禁用插件 {plugin_name} 时发生错误: {e}")
            return jsonify({"error": str(e)}), 500
    
    def _api_get_rules(self):
        """
        API: 获取规则列表
        """
        try:
            rules_data = []
            for rule in self.rule_engine.rules:
                rule_info = {
                    "name": rule.name,
                    "pattern": str(rule.pattern),
                    "type": rule.rule_type,
                    "priority": rule.priority,
                    "description": rule.description,
                    "source": rule.source
                }
                if rule.source == 'manual':
                    rule_info['reply'] = rule.handler({}, None)['content']
                rules_data.append(rule_info)
            return jsonify(rules_data)
        except Exception as e:
            self.logger.error(f"获取规则列表时发生错误: {e}")
            return jsonify({"error": str(e)}), 500
    
    async def _api_add_rule(self):
        """
        API: 添加手动规则
        """
        try:
            data = request.get_json()
            if not data or 'name' not in data or 'pattern' not in data or 'reply' not in data:
                return jsonify({"error": "无效的请求数据"}), 400
            
            rule = Rule(
                name=data["name"],
                pattern=data["pattern"],
                handler=self.rule_engine._create_reply_handler(data["reply"]),
                rule_type=data.get("type", "regex"),
                priority=data.get("priority", 0),
                description=data.get("description", ""),
                source='manual'
            )
            
            await self.rule_engine.add_rule(rule)
            return jsonify({"success": True, "message": "规则添加成功"})
        except Exception as e:
            self.logger.error(f"添加规则时发生错误: {e}")
            return jsonify({"error": str(e)}), 500

    async def _api_update_rule(self, rule_name: str):
        """
        API: 更新手动规则
        """
        try:
            data = request.get_json()
            if not data or 'pattern' not in data or 'reply' not in data:
                return jsonify({"error": "无效的请求数据"}), 400

            # 先删除旧规则
            await self.rule_engine.remove_rule(rule_name)

            # 再添加新规则
            rule = Rule(
                name=rule_name, # 使用旧名称
                pattern=data["pattern"],
                handler=self.rule_engine._create_reply_handler(data["reply"]),
                rule_type=data.get("type", "regex"),
                priority=data.get("priority", 0),
                description=data.get("description", ""),
                source='manual'
            )
            await self.rule_engine.add_rule(rule)
            return jsonify({"success": True, "message": "规则更新成功"})
        except Exception as e:
            self.logger.error(f"更新规则时发生错误: {e}")
            return jsonify({"error": str(e)}), 500

    async def _api_delete_rule(self, rule_name: str):
        """
        API: 删除手动规则
        """
        try:
            success = await self.rule_engine.remove_rule(rule_name)
            if success:
                return jsonify({"success": True, "message": "规则删除成功"})
            else:
                return jsonify({"success": False, "message": "规则未找到或无法删除"}), 404
        except Exception as e:
            self.logger.error(f"删除规则时发生错误: {e}")
            return jsonify({"error": str(e)}), 500
    
    async def _api_get_buckets(self):
        """
        API: 获取桶列表
        """
        try:
            bucket_names = await self.bucket_manager.list_buckets()
            buckets = []
            for bucket_name in bucket_names:
                size = await self.bucket_manager.get_bucket_size(bucket_name)
                buckets.append({
                    "name": bucket_name,
                    "size": size
                })
            return jsonify(buckets)
        except Exception as e:
            self.logger.error(f"获取桶列表时发生错误: {e}")
            return jsonify({"error": str(e)}), 500

    async def _api_create_bucket(self):
        """
        API: 创建新桶
        """
        try:
            data = request.get_json()
            bucket_name = data.get('name')
            if not bucket_name:
                return jsonify({"error": "桶名称不能为空"}), 400
            
            success = await self.bucket_manager.create_bucket(bucket_name)
            if success:
                return jsonify({"success": True, "message": f"桶 {bucket_name} 创建成功"})
            else:
                return jsonify({"success": False, "message": f"桶 {bucket_name} 已存在"}), 409
        except Exception as e:
            self.logger.error(f"创建桶时发生错误: {e}")
            return jsonify({"error": str(e)}), 500

    async def _api_get_bucket_data(self, bucket_name: str):
        """
        API: 获取桶数据
        """
        try:
            data = await self.bucket_manager.get_all(bucket_name)
            return jsonify(data)
        except Exception as e:
            self.logger.error(f"获取桶 {bucket_name} 数据时发生错误: {e}")
            return jsonify({"error": str(e)}), 500

    async def _api_update_bucket_data(self, bucket_name: str):
        """
        API: 更新或创建桶中的数据
        """
        try:
            data = request.get_json()
            if not data or 'key' not in data or 'value' not in data:
                return jsonify({"error": "无效的请求数据，需要'key'和'value'"}), 400
            
            key = data['key']
            value = data['value']
            
            await self.bucket_manager.set(bucket_name, key, value)
            return jsonify({"success": True, "message": f"数据已在桶 {bucket_name} 中更新"})
        except Exception as e:
            self.logger.error(f"更新桶 {bucket_name} 数据时发生错误: {e}")
            return jsonify({"error": str(e)}), 500

    async def _api_delete_bucket_data(self, bucket_name: str, key: str):
        """
        API: 删除桶中的数据
        """
        try:
            await self.bucket_manager.delete(bucket_name, key)
            return jsonify({"success": True, "message": f"键 {key} 已从桶 {bucket_name} 中删除"})
        except Exception as e:
            self.logger.error(f"删除桶 {bucket_name} 中的键 {key} 时发生错误: {e}")
            return jsonify({"error": str(e)}), 500
    
    def _api_get_logs(self):
        """
        API: 获取日志
        """
        try:
            return jsonify(list(log_queue))
        except Exception as e:
            self.logger.error(f"获取日志时发生错误: {e}")
            return jsonify({"error": str(e)}), 500

    def _api_clear_logs(self):
        """
        API: 清空日志
        """
        try:
            log_queue.clear()
            self.logger.info("日志已通过Web UI清空")
            return jsonify({"success": True, "message": "日志已清空"})
        except Exception as e:
            self.logger.error(f"清空日志时发生错误: {e}")
            return jsonify({"error": str(e)}), 500
    
    def _api_get_plugin_content(self, plugin_name: str):
        """
        API: 获取插件内容
        """
        try:
            plugin_file = os.path.join(self.plugin_manager.plugins_dir, f"{plugin_name}.py")
            if not os.path.exists(plugin_file):
                return jsonify({"error": "插件文件不存在"}), 404
            
            with open(plugin_file, 'r', encoding='utf-8') as f:
                content = f.read()
            
            return jsonify({"content": content})
        except Exception as e:
            self.logger.error(f"获取插件 {plugin_name} 内容时发生错误: {e}")
            return jsonify({"error": str(e)}), 500
    
    async def _api_save_plugin_content(self, plugin_name: str):
        """
        API: 保存插件内容
        """
        try:
            data = request.get_json()
            if not data or 'content' not in data:
                return jsonify({"error": "无效的请求数据"}), 400
            
            content = data['content']
            plugin_file = os.path.join(self.plugin_manager.plugins_dir, f"{plugin_name}.py")
            
            with open(plugin_file, 'w', encoding='utf-8') as f:
                f.write(content)
            
            success = await self.plugin_manager.reload_plugin(plugin_name)
            if success:
                return jsonify({"success": True, "message": f"插件 {plugin_name} 保存并重载成功"})
            else:
                return jsonify({"success": False, "message": f"插件 {plugin_name} 保存成功但重载失败"})
        except Exception as e:
            self.logger.error(f"保存插件 {plugin_name} 内容时发生错误: {e}")
            return jsonify({"error": str(e)}), 500
    
    def _api_get_adapter_config(self):
        """
        API: 获取适配器配置
        """
        try:
            config = {"qq_ws": {"host": "localhost", "port": 8080, "access_token": "", "enabled": True}}
            return jsonify(config)
        except Exception as e:
            self.logger.error(f"获取适配器配置时发生错误: {e}")
            return jsonify({"error": str(e)}), 500
    
    def _api_save_adapter_config(self):
        """
        API: 保存适配器配置
        """
        try:
            data = request.get_json()
            if not data:
                return jsonify({"error": "无效的请求数据"}), 400
            return jsonify({"success": True, "message": "适配器配置保存成功"})
        except Exception as e:
            self.logger.error(f"保存适配器配置时发生错误: {e}")
            return jsonify({"error": str(e)}), 500
    
    def _api_create_plugin(self):
        """
        API: 创建新插件
        """
        try:
            data = request.get_json()
            if not data or 'name' not in data:
                return jsonify({"error": "无效的请求数据"}), 400
            
            plugin_name = data['name']
            plugin_content = data.get('content', f'"""\n{plugin_name} 插件\n"""\n\n__description__ = "{plugin_name} 插件描述"\n__version__ = "1.0.0"\n__author__ = "开发者"\n\nrules = []\n\n\ndef handle_message(msg, middleware):\n    pass\n\n\ndef unload():\n    pass\n')
            
            plugin_file = os.path.join(self.plugin_manager.plugins_dir, f"{plugin_name}.py")
            
            if os.path.exists(plugin_file):
                return jsonify({"error": "插件已存在"}), 400
            
            with open(plugin_file, 'w', encoding='utf-8') as f:
                f.write(plugin_content)
            
            return jsonify({"success": True, "message": f"插件 {plugin_name} 创建成功"})
        except Exception as e:
            self.logger.error(f"创建插件时发生错误: {e}")
            return jsonify({"error": str(e)}), 500
    
    def run(self, debug: bool = False):
        """
        运行Web服务器
        """
        self.logger.info(f"Web UI 服务器启动在 {self.host}:{self.port}")
        self.app.run(host=self.host, port=self.port, debug=debug)
    
    async def run_async(self, debug: bool = False):
        """
        异步运行Web服务器
        """
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, self.run, debug)