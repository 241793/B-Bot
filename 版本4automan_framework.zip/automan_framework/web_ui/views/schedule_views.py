from flask import Blueprint, jsonify, request
from scheduler import scheduler
from jobs import send_command_job
from middleware.middleware import Middleware
import croniter
from datetime import datetime
from apscheduler.triggers.cron import CronTrigger
from apscheduler.jobstores.base import JobLookupError

schedule_bp = Blueprint('schedule', __name__)

def init_app(middleware: Middleware):
    # 这个函数现在只是为了保持与 web_app.py 中调用的一致性
    pass

@schedule_bp.route('/api/schedule/jobs', methods=['GET'])
def get_jobs():
    try:
        jobs = scheduler.get_jobs()
        job_details = []
        for job in jobs:
            try:
                if isinstance(job.trigger, CronTrigger):
                    trigger_fields = {f.name: str(f) for f in job.trigger.fields}
                    cron_str = (
                        f"{trigger_fields.get('minute', '*')}"
                        f" {trigger_fields.get('hour', '*')}"
                        f" {trigger_fields.get('day', '*')}"
                        f" {trigger_fields.get('month', '*')}"
                        f" {trigger_fields.get('day_of_week', '*')}"
                    )
                else:
                    cron_str = str(job.trigger) # Fallback for other trigger types
            except Exception:
                cron_str = str(job.trigger) # Fallback

            job_details.append({
                'id': job.id,
                'name': job.name,
                'cron': cron_str,
                'command': job.args[0] if job.args else 'N/A',
                'next_run_time': job.next_run_time.strftime('%Y-%m-%d %H:%M:%S') if job.next_run_time else 'N/A',
            })
        return jsonify(job_details)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@schedule_bp.route('/api/schedule/add', methods=['POST'])
def add_job():
    data = request.get_json()
    job_name = data.get('name')
    job_cron = data.get('cron')
    command = data.get('command')

    if not all([job_name, job_cron, command]):
        return jsonify({"success": False, "message": "所有字段都是必填项"}), 400

    try:
        if not croniter.croniter.is_valid(job_cron):
             raise ValueError("无效的 Cron 表达式")
        parts = job_cron.split()
        if len(parts) != 5:
            raise ValueError("Cron 表达式必须有5个部分")
        
        cron_args = {
            'minute': parts[0],
            'hour': parts[1],
            'day': parts[2],
            'month': parts[3],
            'day_of_week': parts[4]
        }

        scheduler.add_job(
            send_command_job,
            'cron',
            id=job_name,
            name=job_name,
            args=[command],
            **cron_args,
            replace_existing=True
        )
        return jsonify({"success": True, "message": "任务添加成功"})
    except Exception as e:
        return jsonify({"success": False, "message": f"添加任务失败: {e}"}), 500

@schedule_bp.route('/api/schedule/update/<job_id>', methods=['POST'])
def update_job(job_id):
    data = request.get_json()
    job_cron = data.get('cron')
    command = data.get('command')

    if not all([job_cron, command]):
        return jsonify({"success": False, "message": "Cron表达式和指令是必填项"}), 400

    try:
        if not croniter.croniter.is_valid(job_cron):
            raise ValueError("无效的 Cron 表达式")
        parts = job_cron.split()
        if len(parts) != 5:
            raise ValueError("Cron 表达式必须有5个部分")

        cron_args = {
            'minute': parts[0],
            'hour': parts[1],
            'day': parts[2],
            'month': parts[3],
            'day_of_week': parts[4]
        }
        
        # 1. 先修改任务的参数 (command)
        scheduler.modify_job(job_id, args=[command])
        
        # 2. 再使用 reschedule_job 来更新触发器，这将强制重新计算下次运行时间
        scheduler.reschedule_job(job_id, trigger='cron', **cron_args)
        
        return jsonify({"success": True, "message": "任务更新成功"})
    except JobLookupError:
        return jsonify({"success": False, "message": f"任务 '{job_id}' 未找到"}), 404
    except Exception as e:
        return jsonify({"success": False, "message": f"更新任务失败: {e}"}), 500

@schedule_bp.route('/api/schedule/run/<job_id>', methods=['POST'])
def run_job_now(job_id):
    """
    手动触发一个任务立即执行
    """
    try:
        job = scheduler.get_job(job_id)
        if not job:
            raise JobLookupError(job_id)
        
        # 正确的方式是使用 add_job 创建一个立即执行的一次性任务
        scheduler.add_job(job.func, args=job.args, kwargs=job.kwargs, name=f"手动运行 - {job.name}")
        
        return jsonify({"success": True, "message": f"任务 '{job_id}' 已被手动触发执行。"})
    except JobLookupError:
        return jsonify({"success": False, "message": f"任务 '{job_id}' 未找到"}), 404
    except Exception as e:
        return jsonify({"success": False, "message": f"手动运行任务失败: {e}"}), 500

@schedule_bp.route('/api/schedule/remove/<job_id>', methods=['DELETE'])
def remove_job(job_id):
    try:
        scheduler.remove_job(job_id)
        return jsonify({"success": True, "message": "任务移除成功"})
    except JobLookupError:
        return jsonify({"success": False, "message": f"任务 '{job_id}' 未找到"}), 404
    except Exception as e:
        return jsonify({"success": False, "message": f"移除任务失败: {e}"}), 500
