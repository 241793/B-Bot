// script.js

// Global variable to hold the data of the currently viewed bucket
let currentBucketData = {};
// Global variable to hold the full list of dependencies for client-side filtering
let allDependencies = [];
// Global variable to hold the full list of rules for client-side access
let allRules = [];
// Global variable to hold the full list of jobs for client-side access
let allJobs = [];
// Global variable to hold all adapters data, including config
let allAdapters = {};
// Global timer for system stats polling
let statsInterval = null;


document.addEventListener('DOMContentLoaded', function() {
    // Check if we are on the main dashboard page, not login/register
    if (document.getElementById('dashboard-section')) {
        showSection('dashboard');
        refreshData();
    }

    const chatInput = document.getElementById('chat-input');
    if (chatInput) {
        chatInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                sendMessage();
            }
        });
    }
});

function showSection(sectionId) {
    // Clear existing interval if it exists
    if (statsInterval) {
        clearInterval(statsInterval);
        statsInterval = null;
    }

    // 隐藏所有部分
    document.querySelectorAll('.section').forEach(section => {
        section.style.display = 'none';
    });

    // 显示所选部分
    const sectionToShow = document.getElementById(sectionId + '-section');
    if (sectionToShow) {
        sectionToShow.style.display = 'block';
    }

    // 更新导航链接状态
    document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
    });
    
    const activeLink = document.querySelector(`.nav-link[onclick="showSection('${sectionId}')"]`);
    if (activeLink) {
        activeLink.classList.add('active');
    }


    // 根据所选部分加载数据
    switch (sectionId) {
        case 'dashboard':
            refreshData();
            updateSystemStats(); // Initial update
            statsInterval = setInterval(updateSystemStats, 2000); // Start polling only for dashboard
            break;
        case 'chat':
            // No initial data load needed for chat
            break;
        case 'adapters':
            loadAdapters();
            break;
        case 'plugins':
            loadPlugins();
            break;
        case 'rules':
            loadRules();
            break;
        case 'buckets':
            loadBuckets();
            break;
        case 'schedule':
            loadScheduledJobs();
            break;
        case 'dependencies':
            loadDependencies();
            break;
        case 'logs':
            loadLogs();
            break;
        case 'system-config':
            loadSystemConfig();
            break;
    }
}

function refreshData() {
    fetch('/api/status')
        .then(response => response.json())
        .then(data => {
            document.getElementById('plugins-count').innerText = data.plugins_loaded || 0;
            document.getElementById('rules-count').innerText = data.rules_loaded || 0;
            document.getElementById('buckets-count').innerText = data.buckets_count || 0;
            document.getElementById('adapters-count').innerText = data.adapters_count || 0;
        })
        .catch(error => console.error('获取状态失败:', error));
}

function updateSystemStats() {
    const cpuProgress = document.getElementById('cpu-progress');
    const memoryProgress = document.getElementById('memory-progress');
    // If the elements don't exist (e.g., user navigated away), do nothing.
    if (!cpuProgress || !memoryProgress) {
        return;
    }

    fetch('/api/system/stats')
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                console.error('获取系统状态失败:', data.error);
                return;
            }
            cpuProgress.style.width = `${data.cpu_percent}%`;
            cpuProgress.setAttribute('aria-valuenow', data.cpu_percent);
            cpuProgress.innerText = `${data.cpu_percent.toFixed(1)}%`;

            memoryProgress.style.width = `${data.memory_percent}%`;
            memoryProgress.setAttribute('aria-valuenow', data.memory_percent);
            memoryProgress.innerText = `${data.memory_percent.toFixed(1)}%`;
        })
        .catch(error => {
            // Don't log error if the dashboard is not visible
        });
}

function sendMessage() {
    const chatInput = document.getElementById('chat-input');
    const chatBox = document.getElementById('chat-box');
    const message = chatInput.value.trim();

    if (message === '') {
        return;
    }

    // Display user message
    const userMessageElement = document.createElement('div');
    userMessageElement.classList.add('chat-message', 'user-message');
    userMessageElement.textContent = message;
    chatBox.appendChild(userMessageElement);

    chatInput.value = '';
    chatBox.scrollTop = chatBox.scrollHeight;

    // Send message to backend
    fetch('/api/chat', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ message: message })
    })
    .then(response => response.json())
    .then(data => {
        // Display bot response
        const botMessageElement = document.createElement('div');
        botMessageElement.classList.add('chat-message', 'bot-message');
        botMessageElement.textContent = data.reply;
        chatBox.appendChild(botMessageElement);
        chatBox.scrollTop = chatBox.scrollHeight;
    })
    .catch(error => {
        console.error('Error sending message:', error);
        const errorMessageElement = document.createElement('div');
        errorMessageElement.classList.add('chat-message', 'bot-message');
        errorMessageElement.textContent = 'Error: Could not get a response from the bot.';
        chatBox.appendChild(errorMessageElement);
        chatBox.scrollTop = chatBox.scrollHeight;
    });
}

function loadAdapters() {
    fetch('/api/adapters')
        .then(response => response.json())
        .then(data => {
            allAdapters = data; // Store all adapters data globally
            const tableBody = document.getElementById('adapters-table-body');
            tableBody.innerHTML = '';
            for (const name in data) {
                const adapter = data[name];
                const row = `<tr>
                    <td>${adapter.name}</td>
                    <td>${adapter.type}</td>
                    <td>
                        <span class="badge ${adapter.connected ? 'bg-success' : 'bg-danger'}">
                            ${adapter.connected ? '已连接' : '未连接'}
                        </span>
                    </td>
                    <td>
                        <button class="btn btn-sm btn-primary" onclick="openAdapterConfigModal('${adapter.name}')">配置</button>
                    </td>
                </tr>`;
                tableBody.innerHTML += row;
            }
        })
        .catch(error => console.error('获取适配器失败:', error));
}

function openAdapterConfigModal(adapterName) {
    const adapter = allAdapters[adapterName];
    if (!adapter) {
        alert('未找到适配器配置。');
        return;
    }

    document.getElementById('adapterConfigModalTitle').innerText = `适配器配置: ${adapterName}`;
    const configContent = document.getElementById('adapter-config-content');
    
    // The config is now part of the adapter data from the API
    const configToDisplay = adapter.config ? JSON.stringify(adapter.config, null, 2) : '此适配器没有可显示的配置。';
    configContent.textContent = configToDisplay;

    new bootstrap.Modal(document.getElementById('adapterConfigModal')).show();
}


function loadPlugins() {
    fetch('/api/plugins')
        .then(response => response.json())
        .then(data => {
            const tableBody = document.getElementById('plugins-table-body');
            tableBody.innerHTML = '';
            for (const name in data) {
                const plugin = data[name];
                const statusBadge = plugin.is_loaded 
                    ? `<span class="badge bg-success">已加载</span>`
                    : (plugin.enabled ? `<span class="badge bg-secondary">未加载</span>` : `<span class="badge bg-danger">已禁用</span>`);

                const toggleButton = plugin.enabled
                    ? `<button class="btn btn-sm btn-secondary" onclick="togglePlugin('${plugin.name}', true)">禁用</button>`
                    : `<button class="btn btn-sm btn-success" onclick="togglePlugin('${plugin.name}', false)">启用</button>`;

                const row = `<tr>
                    <td>${plugin.name}</td>
                    <td>${plugin.version}</td>
                    <td>${plugin.author}</td>
                    <td>${plugin.description}</td>
                    <td>${plugin.rules_count}</td>
                    <td>${statusBadge}</td>
                    <td>
                        ${toggleButton}
                        <button class="btn btn-sm btn-info" onclick="reloadPlugin('${plugin.name}')" ${!plugin.enabled ? 'disabled' : ''}>重载</button>
                        <button class="btn btn-sm btn-warning" onclick="openEditPluginModal('${plugin.name}')">编辑</button>
                        <button class="btn btn-sm btn-danger" onclick="deletePlugin('${plugin.name}')">删除</button>
                    </td>
                </tr>`;
                tableBody.innerHTML += row;
            }
        })
        .catch(error => console.error('获取插件失败:', error));
}

function togglePlugin(pluginName, isEnabled) {
    const action = isEnabled ? 'disable' : 'enable';
    fetch(`/api/plugins/${pluginName}/${action}`, { method: 'POST' })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                loadPlugins();
            } else {
                alert(`操作失败: ${data.message}`);
            }
        })
        .catch(error => console.error('操作插件失败:', error));
}

function reloadPlugin(pluginName) {
    fetch(`/api/plugins/${pluginName}/reload`, { method: 'POST' })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('插件重载成功');
                loadPlugins();
            } else {
                alert(`重载失败: ${data.message}`);
            }
        })
        .catch(error => console.error('重载插件失败:', error));
}

function deletePlugin(pluginName) {
    if (!confirm(`确定要删除插件 "${pluginName}" 吗? 这将从磁盘上永久删除文件。`)) {
        return;
    }

    fetch(`/api/plugins/${pluginName}`, { method: 'DELETE' })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('插件删除成功');
                loadPlugins();
            } else {
                alert(`删除失败: ${data.message}`);
            }
        })
        .catch(error => console.error('删除插件失败:', error));
}

function openEditPluginModal(pluginName) {
    document.getElementById('edit-plugin-name').value = pluginName;
    document.getElementById('editPluginModalTitle').innerText = `编辑插件: ${pluginName}`;

    fetch(`/api/plugins/${pluginName}/content`)
        .then(response => response.json())
        .then(data => {
            if (data.content) {
                document.getElementById('plugin-content-editor').value = data.content;
                new bootstrap.Modal(document.getElementById('editPluginModal')).show();
            } else {
                alert(`获取插件内容失败: ${data.error}`);
            }
        })
        .catch(error => console.error('获取插件内容失败:', error));
}

function savePluginContent() {
    const pluginName = document.getElementById('edit-plugin-name').value;
    const content = document.getElementById('plugin-content-editor').value;

    fetch(`/api/plugins/${pluginName}/content`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('插件保存并重载成功');
            bootstrap.Modal.getInstance(document.getElementById('editPluginModal')).hide();
            loadPlugins();
        } else {
            alert(`保存失败: ${data.message}`);
        }
    })
    .catch(error => console.error('保存插件失败:', error));
}

function scanPlugins() {
    fetch('/api/plugins/scan')
        .then(response => response.json())
        .then(data => {
            alert('扫描到以下插件: \n' + data.join('\n'));
            loadPlugins();
        })
        .catch(error => console.error('扫描插件失败:', error));
}

function createPlugin() {
    const name = document.getElementById('plugin-name').value;
    const description = document.getElementById('plugin-description').value;

    if (!name) {
        alert('插件名称不能为空');
        return;
    }

    fetch('/api/plugins/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, description })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('插件创建成功');
            bootstrap.Modal.getInstance(document.getElementById('createPluginModal')).hide();
            loadPlugins();
        } else {
            alert(`创建失败: ${data.error}`);
        }
    })
    .catch(error => console.error('创建插件失败:', error));
}

function loadRules() {
    fetch('/api/rules')
        .then(response => response.json())
        .then(data => {
            allRules = data; // Store for editing
            const tableBody = document.getElementById('rules-table-body');
            tableBody.innerHTML = '';
            data.forEach(rule => {
                const replyContent = rule.source === 'manual' ? rule.reply : '<em>由插件定义</em>';
                const actions = rule.source === 'manual' 
                    ? `<button class="btn btn-sm btn-warning" onclick="openRuleModal('${rule.name}')">编辑</button>
                       <button class="btn btn-sm btn-danger" onclick="deleteRule('${rule.name}')">删除</button>`
                    : '';

                const row = `<tr>
                    <td>${rule.name}</td>
                    <td>${rule.type}</td>
                    <td>${rule.pattern}</td>
                    <td>${escapeHtml(replyContent)}</td>
                    <td><span class="badge ${rule.source === 'manual' ? 'bg-info' : 'bg-secondary'}">${rule.source}</span></td>
                    <td>${actions}</td>
                </tr>`;
                tableBody.innerHTML += row;
            });
        })
        .catch(error => console.error('获取规则失败:', error));
}

function openRuleModal(ruleName = null) {
    const form = document.getElementById('rule-form');
    form.reset();
    
    const modalTitle = document.getElementById('ruleModalTitle');
    const nameInput = document.getElementById('rule-name');
    const originalNameInput = document.getElementById('rule-original-name');

    if (ruleName) { // Edit mode
        const rule = allRules.find(r => r.name === ruleName);
        if (!rule) return;

        modalTitle.innerText = '编辑手动规则';
        originalNameInput.value = rule.name;
        nameInput.value = rule.name;
        nameInput.readOnly = true;
        document.getElementById('rule-type').value = rule.type;
        document.getElementById('rule-pattern').value = rule.pattern;
        document.getElementById('rule-reply').value = rule.reply;
        document.getElementById('rule-priority').value = rule.priority;
    } else { // Add mode
        modalTitle.innerText = '添加手动规则';
        originalNameInput.value = '';
        nameInput.readOnly = false;
    }
    new bootstrap.Modal(document.getElementById('ruleModal')).show();
}

function saveRule() {
    const originalName = document.getElementById('rule-original-name').value;
    const isEditing = !!originalName;

    const ruleData = {
        name: document.getElementById('rule-name').value,
        type: document.getElementById('rule-type').value,
        pattern: document.getElementById('rule-pattern').value,
        reply: document.getElementById('rule-reply').value,
        priority: parseInt(document.getElementById('rule-priority').value)
    };

    if (!ruleData.name || !ruleData.pattern || !ruleData.reply) {
        alert('规则名称、匹配模式和回复内容不能为空');
        return;
    }

    const url = isEditing ? `/api/rules/update/${originalName}` : '/api/rules';
    const method = 'POST';

    fetch(url, {
        method: method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(ruleData)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            bootstrap.Modal.getInstance(document.getElementById('ruleModal')).hide();
            loadRules();
        } else {
            alert(`${isEditing ? '更新' : '添加'}失败: ${data.message || data.error}`);
        }
    })
    .catch(error => console.error(`${isEditing ? '更新' : '添加'}规则失败:`, error));
}


function deleteRule(ruleName) {
    if (!confirm(`确定要删除规则 "${ruleName}" 吗?`)) {
        return;
    }

    fetch(`/api/rules/${ruleName}`, { method: 'DELETE' })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                loadRules();
            } else {
                alert(`删除失败: ${data.message}`);
            }
        })
        .catch(error => console.error('删除规则失败:', error));
}

function loadBuckets() {
    fetch('/api/buckets')
        .then(response => response.json())
        .then(data => {
            const tableBody = document.getElementById('buckets-table-body');
            tableBody.innerHTML = '';
            data.forEach(bucket => {
                const row = `<tr>
                    <td>${bucket.name}</td>
                    <td>${bucket.size}</td>
                    <td>
                        <button class="btn btn-sm btn-primary" onclick="openEditBucketModal('${bucket.name}')">
                            查看/编辑
                        </button>
                    </td>
                </tr>`;
                tableBody.innerHTML += row;
            });
        })
        .catch(error => console.error('获取数据桶失败:', error));
}

function addBucket() {
    const bucketName = document.getElementById('new-bucket-name').value;
    if (!bucketName) {
        alert('桶名称不能为空');
        return;
    }

    fetch('/api/buckets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: bucketName })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('桶创建成功');
            bootstrap.Modal.getInstance(document.getElementById('addBucketModal')).hide();
            loadBuckets();
        } else {
            alert(`创建失败: ${data.message}`);
        }
    })
    .catch(error => console.error('创建桶失败:', error));
}

function openEditBucketModal(bucketName) {
    document.getElementById('edit-bucket-name').value = bucketName;
    document.getElementById('editBucketModalTitle').innerText = `编辑数据桶: ${bucketName}`;
    cancelEditBucketItem(); // 隐藏编辑表单

    fetch(`/api/buckets/${bucketName}`)
        .then(response => response.json())
        .then(data => {
            currentBucketData = data; // Store the fetched data
            const tableBody = document.getElementById('bucket-data-table-body');
            tableBody.innerHTML = '';
            for (const key in data) {
                const valueString = JSON.stringify(data[key], null, 2);
                const row = `<tr>
                    <td>${key}</td>
                    <td><pre>${escapeHtml(valueString)}</pre></td>
                    <td>
                        <button class="btn btn-sm btn-info" onclick="editBucketItem('${key}')">编辑</button>
                        <button class="btn btn-sm btn-danger" onclick="deleteBucketData('${bucketName}', '${key}')">删除</button>
                    </td>
                </tr>`;
                tableBody.innerHTML += row;
            }
            new bootstrap.Modal(document.getElementById('editBucketModal')).show();
        })
        .catch(error => console.error(`获取桶 ${bucketName} 数据失败:`, error));
}

function addNewBucketItem() {
    document.getElementById('edit-bucket-key').value = '';
    document.getElementById('edit-bucket-value').value = '';
    document.getElementById('edit-bucket-item-form').style.display = 'block';
    document.getElementById('edit-bucket-key').readOnly = false;
}

function editBucketItem(key) {
    const value = currentBucketData[key];
    document.getElementById('edit-bucket-key').value = key;
    document.getElementById('edit-bucket-value').value = JSON.stringify(value, null, 2);
    document.getElementById('edit-bucket-item-form').style.display = 'block';
    document.getElementById('edit-bucket-key').readOnly = true;
}

function cancelEditBucketItem() {
    document.getElementById('edit-bucket-item-form').style.display = 'none';
}

function saveBucketData() {
    const bucketName = document.getElementById('edit-bucket-name').value;
    const key = document.getElementById('edit-bucket-key').value;
    let value;

    if (!key) {
        alert('键不能为空');
        return;
    }

    try {
        value = JSON.parse(document.getElementById('edit-bucket-value').value);
    } catch (e) {
        alert('值必须是有效的JSON格式');
        return;
    }

    fetch(`/api/buckets/${bucketName}/data`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ key, value })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            const modalInstance = bootstrap.Modal.getInstance(document.getElementById('editBucketModal'));
            if (modalInstance) {
                modalInstance.hide();
            }
            openEditBucketModal(bucketName);
        } else {
            alert(`保存失败: ${data.error}`);
        }
    })
    .catch(error => console.error('保存数据失败:', error));
}

function deleteBucketData(bucketName, key) {
    if (!confirm(`确定要删除键 "${key}" 吗?`)) {
        return;
    }

    fetch(`/api/buckets/${bucketName}/data/${key}`, { method: 'DELETE' })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const modalInstance = bootstrap.Modal.getInstance(document.getElementById('editBucketModal'));
                if (modalInstance) {
                    modalInstance.hide();
                }
                openEditBucketModal(bucketName);
            } else {
                alert(`删除失败: ${data.message}`);
            }
        })
        .catch(error => console.error('删除数据失败:', error));
}

function loadLogs() {
    fetch('/api/logs')
        .then(response => response.json())
        .then(data => {
            const logsContent = document.getElementById('logs-content');
            logsContent.innerHTML = '';
            if (Array.isArray(data)) {
                logsContent.textContent = data.join('\n');
            } else {
                logsContent.textContent = '加载日志失败。';
            }
        })
        .catch(error => {
            console.error('获取日志失败:', error);
            document.getElementById('logs-content').textContent = '获取日志失败。';
        });
}

function clearLogs() {
    if (!confirm('确定要清空所有当前显示的日志吗?')) {
        return;
    }
    fetch('/api/logs/clear', { method: 'POST' })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                loadLogs();
            } else {
                alert('清空日志失败: ' + data.message);
            }
        })
        .catch(error => console.error('清空日志失败:', error));
}

// --- Schedule Functions ---
function loadScheduledJobs() {
    fetch('/api/schedule/jobs')
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                alert('加载计划任务失败: ' + data.error);
                return;
            }
            allJobs = data; // Store for editing
            const tableBody = document.getElementById('schedule-table-body');
            tableBody.innerHTML = '';
            data.forEach(job => {
                const row = `<tr>
                    <td>${job.name}</td>
                    <td>${job.cron}</td>
                    <td>${escapeHtml(job.command)}</td>
                    <td>${job.next_run_time}</td>
                    <td>
                        <button class="btn btn-sm btn-success" onclick="runJobNow('${job.id}', event)">运行</button>
                        <button class="btn btn-sm btn-warning" onclick="openJobModal('${job.id}')">编辑</button>
                        <button class="btn btn-sm btn-danger" onclick="removeScheduledJob('${job.id}')">删除</button>
                    </td>
                </tr>`;
                tableBody.innerHTML += row;
            });
        })
        .catch(error => console.error('加载计划任务失败:', error));
}

function openJobModal(jobId = null) {
    const form = document.getElementById('job-form');
    form.reset();
    
    const modalTitle = document.getElementById('jobModalTitle');
    const nameInput = document.getElementById('job-name');
    const idInput = document.getElementById('job-id');

    if (jobId) { // Edit mode
        const job = allJobs.find(j => j.id === jobId);
        if (!job) return;

        modalTitle.innerText = '编辑计划任务';
        idInput.value = job.id;
        nameInput.value = job.name;
        nameInput.readOnly = true;
        document.getElementById('job-cron').value = job.cron;
        document.getElementById('job-command').value = job.command;
    } else { // Add mode
        modalTitle.innerText = '添加计划任务';
        idInput.value = '';
        nameInput.readOnly = false;
    }
    new bootstrap.Modal(document.getElementById('jobModal')).show();
}

function saveScheduledJob() {
    const jobId = document.getElementById('job-id').value;
    const isEditing = !!jobId;

    const jobData = {
        name: document.getElementById('job-name').value,
        cron: document.getElementById('job-cron').value,
        command: document.getElementById('job-command').value,
    };

    if (!jobData.name || !jobData.cron || !jobData.command) {
        alert('所有字段均为必填项');
        return;
    }

    const url = isEditing ? `/api/schedule/update/${jobId}` : '/api/schedule/add';
    const method = 'POST';

    fetch(url, {
        method: method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(jobData)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            bootstrap.Modal.getInstance(document.getElementById('jobModal')).hide();
            loadScheduledJobs();
        } else {
            alert(`${isEditing ? '更新' : '添加'}任务失败: ${data.message}`);
        }
    })
    .catch(error => console.error(`${isEditing ? '更新' : '添加'}任务失败:`, error));
}

function removeScheduledJob(jobId) {
    if (!confirm(`确定要删除任务 "${jobId}" 吗?`)) {
        return;
    }

    fetch(`/api/schedule/remove/${jobId}`, { method: 'DELETE' })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                loadScheduledJobs();
            } else {
                alert(`删除任务失败: ${data.message}`);
            }
        })
        .catch(error => console.error('删除任务失败:', error));
}

function runJobNow(jobId, event) {
    const runBtn = event.target;
    runBtn.disabled = true;
    runBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';

    fetch(`/api/schedule/run/${jobId}`, { method: 'POST' })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert(data.message);
            } else {
                alert(`手动运行失败: ${data.message}`);
            }
        })
        .catch(error => {
            console.error('手动运行任务失败:', error);
            alert('手动运行任务时发生网络错误。');
        })
        .finally(() => {
            runBtn.disabled = false;
            runBtn.innerText = '运行';
        });
}


// --- System Config Functions ---
function loadSystemConfig() {
    fetch('/api/system/config')
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                alert('加载系统配置失败: ' + data.error);
                return;
            }
            document.getElementById('config-reverse-ws-port').value = data.reverse_ws_port || '';
            document.getElementById('config-admin-list').value = (data.admin_list || []).join(' & ');
            document.getElementById('config-version-number').value = data.version_number || '';
            document.getElementById('config-version-content').value = data.version_content || '';
            document.getElementById('config-private-reply-enabled').checked = data.private_reply_enabled;
            document.getElementById('config-group-reply-enabled').checked = data.group_reply_enabled;
            document.getElementById('config-group-blacklist').value = (data.group_blacklist || []).join(' & ');
        })
        .catch(error => console.error('加载系统配置失败:', error));
}

function saveSystemConfig() {
    const configData = {
        reverse_ws_port: document.getElementById('config-reverse-ws-port').value,
        admin_list: document.getElementById('config-admin-list').value,
        version_number: document.getElementById('config-version-number').value,
        version_content: document.getElementById('config-version-content').value,
        private_reply_enabled: document.getElementById('config-private-reply-enabled').checked,
        group_reply_enabled: document.getElementById('config-group-reply-enabled').checked,
        group_blacklist: document.getElementById('config-group-blacklist').value,
    };

    const statusDiv = document.getElementById('config-save-status');
    statusDiv.textContent = '正在保存...';
    statusDiv.className = 'mt-3 text-info';

    fetch('/api/system/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(configData)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            statusDiv.textContent = '保存成功！请注意，端口等网络设置需要重启框架后才能生效。';
            statusDiv.className = 'mt-3 text-success';
        } else {
            statusDiv.textContent = '保存失败: ' + data.message;
            statusDiv.className = 'mt-3 text-danger';
        }
        setTimeout(() => statusDiv.textContent = '', 5000);
    })
    .catch(error => {
        statusDiv.textContent = '保存出错: ' + error;
        statusDiv.className = 'mt-3 text-danger';
        console.error('保存系统配置失败:', error);
    });
}

// --- Dependency Management Functions ---
function loadDependencies() {
    const tableBody = document.getElementById('dependencies-table-body');
    tableBody.innerHTML = '<tr><td colspan="3">正在加载依赖列表...</td></tr>';

    fetch('/api/dependencies')
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            if (!data.success) {
                tableBody.innerHTML = `<tr><td colspan="3" class="text-danger">加载失败: ${escapeHtml(data.output)}</td></tr>`;
                allDependencies = [];
                return;
            }
            allDependencies = data.packages || [];
            renderDependencies(allDependencies);
        })
        .catch(error => {
            console.error('获取依赖列表失败:', error);
            tableBody.innerHTML = `<tr><td colspan="3" class="text-danger">获取依赖列表失败: ${error.message}</td></tr>`;
            allDependencies = [];
        });
}

function renderDependencies(packages) {
    const tableBody = document.getElementById('dependencies-table-body');
    tableBody.innerHTML = '';
    if (packages && packages.length > 0) {
        packages.forEach(pkg => {
            const row = `<tr>
                <td>${escapeHtml(pkg.name)}</td>
                <td>${escapeHtml(pkg.version)}</td>
                <td>
                    <button class="btn btn-sm btn-danger" onclick="uninstallDependency('${escapeHtml(pkg.name)}', event)">
                        <i class="fas fa-trash"></i> 卸载
                    </button>
                </td>
            </tr>`;
            tableBody.innerHTML += row;
        });
    } else {
        tableBody.innerHTML = '<tr><td colspan="3">未找到匹配的依赖包。</td></tr>';
    }
}

function filterDependencies() {
    const searchTerm = document.getElementById('dependency-search').value.toLowerCase();
    const filteredPackages = allDependencies.filter(pkg => pkg.name.toLowerCase().includes(searchTerm));
    renderDependencies(filteredPackages);
}

function installDependency(event) {
    const packageName = document.getElementById('dependency-name').value.trim();
    const indexUrl = document.getElementById('dependency-index').value.trim();

    if (!packageName) {
        alert('请输入要安装的依赖包名称。');
        return;
    }

    const installBtn = event.target;
    installBtn.disabled = true;
    installBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 正在安装...';

    fetch('/api/dependencies/install', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ package_name: packageName, index_url: indexUrl })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert(`依赖包 "${packageName}" 安装成功！`);
            document.getElementById('dependency-name').value = ''; // Clear input on success
        } else {
            alert(`安装失败: \n${data.output}`);
        }
    })
    .catch(error => {
        console.error('安装依赖失败:', error);
        alert('安装依赖时发生网络错误。');
    })
    .finally(() => {
        installBtn.disabled = false;
        installBtn.innerHTML = '<i class="fas fa-download"></i> 安装';
        loadDependencies(); // Refresh the list regardless of outcome
    });
}

function uninstallDependency(packageName, event) {
    if (!confirm(`确定要卸载依赖包 "${packageName}" 吗?`)) {
        return;
    }
    
    const uninstallBtn = event.target.closest('button');
    uninstallBtn.disabled = true;
    uninstallBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';

    fetch('/api/dependencies/uninstall', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ package_name: packageName })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert(`依赖包 "${packageName}" 卸载成功！`);
        } else {
            alert(`卸载失败: \n${data.output}`);
        }
    })
    .catch(error => {
        console.error('卸载依赖失败:', error);
        alert('卸载依赖时发生网络错误。');
    })
    .finally(() => {
        loadDependencies(); // Refresh the list
    });
}


// Utility function to escape HTML to prevent XSS and display issues
function escapeHtml(unsafe) {
    return unsafe
         .replace(/&/g, "&amp;")
         .replace(/</g, "&lt;")
         .replace(/>/g, "&gt;")
         .replace(/"/g, "&quot;")
         .replace(/'/g, "&#039;");
}
