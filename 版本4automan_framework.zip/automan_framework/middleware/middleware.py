"""
中间件核心类
提供给插件调用的各种功能接口
"""
import asyncio
import inspect
import json, re
from typing import Dict, Any, Optional, List, Callable, Tuple
from storage.bucket import BucketManager
from utils.logger import get_logger


class Middleware:
    """
    中间件类，提供给插件调用的各种功能接口
    """

    def __init__(self, bucket_manager: BucketManager):
        """
        初始化中间件
        :param bucket_manager: 桶管理器
        """
        self.bucket_manager = bucket_manager
        self.adapters = {}  # 存储不同平台的适配器
        self.message_handlers = []  # 消息处理器列表
        self.logger = get_logger("middleware")
        # 使用 (user_id, group_id) 元组作为键，确保等待的上下文精确
        self.waiting_for_input: Dict[Tuple[str, Optional[str]], asyncio.Future] = {}

    def _get_session_key(self, msg: Dict[str, Any]) -> Optional[Tuple[str, Optional[str]]]:
        """
        根据消息生成唯一的、标准化的会话标识。
        这是确保 wait_for_input 可靠工作的核心。
        """
        user_id = msg.get("user_id")
        # user_id 必须存在且不为空
        if user_id is None or str(user_id).strip() == '':
            return None

        group_id = msg.get("group_id")

        # 强力标准化group_id：None, '', 0, '0' 都应被视为私聊 (None)
        norm_group_id = None
        if group_id and str(group_id).strip() not in ['', '0']:
            norm_group_id = str(group_id)

        return (str(user_id), norm_group_id)

    def register_adapter(self, name: str, adapter):
        """
        注册适配器
        :param name: 适配器名称
        :param adapter: 适配器实例
        """
        self.adapters[name] = adapter

        # 自动设置适配器的中间件引用
        try:
            adapter.middleware = self
        except AttributeError:
            # 如果适配器不支持设置middleware属性，则跳过
            pass

        self.logger.info(f"适配器 {name} 已注册")

    def register_message_handler(self, handler: Callable):
        """
        注册消息处理器
        :param handler: 消息处理器函数
        """
        self.message_handlers.append(handler)
        self.logger.info(f"消息处理器 {handler.__name__} 已注册")

    async def _run_handlers(self, message: Dict[str, Any]):
        """
        在后台任务中运行消息处理器和拦截逻辑。
        """
        user_id = message.get("user_id")
        group_id = message.get("group_id")
        is_admin_user = await self.is_admin(user_id)

        # --- 拦截逻辑 ---
        if group_id:  # 群聊消息
            group_reply_enabled = await self.bucket_get("system", "group_reply_enabled", True)
            if not group_reply_enabled:
                self.logger.debug(f"群聊回复已禁用，忽略来自群 {group_id} 的消息")
                return
            group_blacklist = await self.bucket_get("system", "group_blacklist", [])
            if str(group_id) in group_blacklist:
                self.logger.debug(f"群 {group_id} 在黑名单中，忽略消息")
                return
        else:  # 私聊消息
            private_reply_enabled = await self.bucket_get("system", "private_reply_enabled", True)
            if not private_reply_enabled and not is_admin_user:
                self.logger.debug(f"私聊回复已对普通用户禁用，忽略来自用户 {user_id} 的消息")
                return

        self.logger.info(f"后台处理消息: {message.get('content', '')}")

        # 调用所有注册的消息处理器
        for handler in self.message_handlers:
            try:
                # 使用 inspect 模块检查函数签名，以决定如何调用
                sig = inspect.signature(handler)
                num_params = len(sig.parameters)

                args = [message]
                # 如果处理函数需要超过1个参数，我们假定第二个是 middleware 实例
                if num_params > 1:
                    args.append(self)

                result = await handler(*args) if asyncio.iscoroutinefunction(handler) else handler(*args)

                if result:
                    await self.send_response(message, result)
                    break
            except Exception as e:
                self.logger.error(f"处理消息时插件 {getattr(handler, '__name__', 'unknown')} 发生错误: {e}",
                                  exc_info=True)

    async def process_message(self, message: Dict[str, Any]):
        """
        处理接收到的消息。
        此函数要么处理一个等待中的回复，要么为新消息创建一个后台处理任务。
        它会立即返回，以防阻塞框架的主循环。
        """
        # 在处理开始时添加可靠的回复目标和群组状态
        if message.get('group_id'):
            message['reply_to'] = message['group_id']
            message['is_group'] = True
        else:
            message['reply_to'] = message['user_id']
            message['is_group'] = False

        # --- 检查是否是等待的输入 ---
        session_key = self._get_session_key(message)
        if session_key:
            waiter = self.waiting_for_input.get(session_key)
            if waiter and not waiter.done():
                self.logger.debug(f"捕获到会话 {session_key} 正在等待的输入")
                waiter.set_result(message)
                return

        # --- 如果不是等待的输入，则在后台任务中处理 ---
        asyncio.create_task(self._run_handlers(message))

    async def send_response(self, original_message: Dict[str, Any], response: Dict[str, Any]):
        """
        发送响应消息
        :param original_message: 原始消息
        :param response: 响应数据
        """
        platform = original_message.get("platform", "default")
        adapter = self.adapters.get(platform)

        if not adapter:
            for name, adapter_instance in self.adapters.items():
                if name in ["reverse_ws", "websocket", "ws_server"]:
                    adapter = adapter_instance
                    break

        if adapter:
            try:
                target_id = original_message.get("group_id") or original_message.get("user_id")
                if original_message.get("group_id"):
                    await adapter.send_group_message(target_id, response.get("content", ""))
                else:
                    await adapter.send_private_message(target_id, response.get("content", ""))
                self.logger.info(f"响应已发送到 {platform} 平台: {response.get('content', '')}")
            except Exception as e:
                self.logger.error(f"发送响应消息失败: {e}")
        else:
            self.logger.error(f"未找到可用的适配器来发送响应到平台 {platform}")

    async def wait_for_input(self, msg: Dict[str, Any], timeout: int) -> Optional[Dict[str, Any]]:
        """
        在当前会话（群聊或私聊）中等待用户的下一次输入。
        :param msg: 原始消息对象，用于确定等待哪个用户和会话。
        :param timeout: 等待的超时时间（毫秒）。
        :return: 用户输入的完整消息对象 (dict)，如果超时或发生错误则返回 None。
        """

        session_key = self._get_session_key(msg)

        if not session_key:
            self.logger.error("wait_for_input: 无法从消息中确定会话。")
            return None

        if session_key in self.waiting_for_input:
            old_future = self.waiting_for_input.pop(session_key)
            if not old_future.done():
                old_future.cancel()

        loop = asyncio.get_running_loop()
        future = loop.create_future()
        self.waiting_for_input[session_key] = future

        self.logger.debug(f"开始在会话 {session_key} 中等待输入，超时时间 {timeout}ms")

        try:
            result = await asyncio.wait_for(future, timeout / 1000.0)
            return result.get("content", None)
        except (asyncio.TimeoutError, asyncio.CancelledError) as e:
            self.logger.debug(f"在会话 {session_key} 中等待输入时发生: {type(e).__name__}")
            return None
        finally:
            if self.waiting_for_input.get(session_key) is future:
                del self.waiting_for_input[session_key]

    # 以下是提供给插件调用的功能接口

    async def send_message(self, platform: str, target_id: str, content: str, message_type: str = "text", *,
                           msg: Optional[Dict[str, Any]] = None):
        """
        发送消息。
        可以提供原始消息 `msg` 对象来获得更智能的上下文判断，以解决在群聊中回复时变成私聊的问题。
        """

        adapter = self.adapters.get(platform)
        if not adapter:
            self.logger.error(f"未找到平台 {platform} 的适配器")
            return False

        final_target_id = target_id
        is_group = False

        # 如果提供了 msg 上下文，则使用其可靠的信息
        if msg and 'is_group' in msg:
            # 检查是否是用户描述的“在群聊中回复用户，却变成私聊”的场景
            if msg['is_group'] and target_id == msg.get('user_id'):
                # 如果是，则自动修正目标为原始群聊
                final_target_id = msg['reply_to']
                is_group = True
            else:
                # 对于其他情况（如私聊回复或目标不是消息发送者），我们尊重传入的 target_id
                # 但我们仍然可以利用 msg 上下文来判断目标是否为群组
                if final_target_id == msg.get('reply_to'):
                    is_group = msg['is_group']
                else:
                    # 如果目标不是原始会话，则回退到基本判断
                    is_group = "group" in str(final_target_id).lower() or str(final_target_id).startswith('@@')
        else:
            # 当没有 msg 上下文时，使用旧的、但经过改进的逻辑
            is_group = "group" in str(final_target_id).lower() or str(final_target_id).startswith('@@')

        try:
            if is_group:
                await adapter.send_group_message(final_target_id, content)
            else:
                await adapter.send_private_message(final_target_id, content)
            self.logger.info(f"消息已发送到 {platform} -> {'群' if is_group else '私聊'}:{final_target_id}")
            return True
        except Exception as e:
            self.logger.error(f"发送消息到 {final_target_id} 失败: {e}")
            return False

    async def get_user_info(self, platform: str, user_id: str) -> Dict[str, Any]:
        """
        获取用户信息。
        会尝试从适配器获取真实信息，如果失败，则返回一个包含基础信息的默认对象，以保证插件的健壮性。
        """
        adapter = self.adapters.get(platform)

        # 尝试从适配器获取真实信息
        if adapter and hasattr(adapter, 'get_user_info'):
            try:
                user_info = await adapter.get_user_info(user_id)
                if user_info:
                    return user_info
            except Exception as e:
                self.logger.error(f"通过适配器 {platform} 获取用户信息 {user_id} 失败: {e}")

        # 如果适配器不存在、没有 get_user_info 方法或获取失败，则返回一个默认对象
        self.logger.warning(f"无法通过适配器获取用户 {user_id} 的信息，将返回默认信息。")
        return {"user_id": user_id, "nickname": f"用户{user_id}", "platform": platform}

    async def get_group_info(self, platform: str, group_id: str) -> Optional[Dict[str, Any]]:
        adapter = self.adapters.get(platform)
        if not adapter: return None
        return {"group_id": group_id, "group_name": f"群组{group_id}", "platform": platform}

    async def notify_admin(self, message: str, platform: str = "reverse_ws"):
        admin_list = await self.bucket_get("system", "admin_list", [])
        if not admin_list:
            self.logger.warning("通知管理员失败：未设置任何管理员。")
            return
        adapter = self.adapters.get(platform)
        if not adapter:
            self.logger.error(f"通知管理员失败：未找到平台 {platform} 的适配器。")
            return
        for admin_id in admin_list:
            try:
                await adapter.send_private_message(admin_id, message)
            except Exception as e:
                self.logger.error(f"向管理员 {admin_id} 发送消息失败: {e}")

    async def reply_with_image(self, original_message: Dict[str, Any], image_source: str):
        if re.match(r'^https?://', image_source):
            cq_code = f"[CQ:image,file={image_source}]"
        elif len(image_source) > 100:
            cq_code = f"[CQ:image,file=base64://{image_source.split(',')[-1]}]"
        else:
            self.logger.error(f"无效的图片源: {image_source[:50]}...")
            return
        await self.send_response(original_message, {"content": cq_code})

    # 持久化存储相关功能
    async def bucket_get(self, bucket_name: str, key: str, default=None):
        return await self.bucket_manager.get(bucket_name, key, default)

    async def bucket_set(self, bucket_name: str, key: str, value: Any):
        await self.bucket_manager.set(bucket_name, key, value)

    async def bucket_delete(self, bucket_name: str, key: str):
        await self.bucket_manager.delete(bucket_name, key)

    async def bucket_keys(self, bucket_name: str) -> List[str]:
        return await self.bucket_manager.keys(bucket_name)

    async def bucket_clear(self, bucket_name: str):
        await self.bucket_manager.clear(bucket_name)

    # 管理员专用功能
    async def is_admin(self, user_id: Any) -> bool:
        if user_id is None: return False
        admin_list = await self.bucket_get("system", "admin_list", [])
        return str(user_id) in admin_list

    async def add_admin(self, user_id: Any, operator_id: Any) -> bool:
        if not await self.is_admin(operator_id):
            self.logger.warning(f"用户 {operator_id} 尝试添加管理员 {user_id}，但不是管理员")
            return False
        admin_list = await self.bucket_get("system", "admin_list", [])
        user_id_str = str(user_id)
        if user_id_str not in admin_list:
            admin_list.append(user_id_str)
            await self.bucket_set("system", "admin_list", admin_list)
            self.logger.info(f"用户 {user_id_str} 已被添加为管理员")
            return True
        return False

    async def remove_admin(self, user_id: Any, operator_id: Any) -> bool:
        if not await self.is_admin(operator_id):
            self.logger.warning(f"用户 {operator_id} 尝试移除管理员 {user_id}，但不是管理员")
            return False
        admin_list = await self.bucket_get("system", "admin_list", [])
        user_id_str = str(user_id)
        if user_id_str in admin_list:
            admin_list.remove(user_id_str)
            await self.bucket_set("system", "admin_list", admin_list)
            self.logger.info(f"用户 {user_id_str} 已被移除管理员权限")
            return True
        return False