import asyncio
from middleware.middleware import Middleware
from typing import Optional

# 全局变量，用于在运行时保存 middleware 实例和主事件循环
_middleware_instance: Optional[Middleware] = None
_main_loop: Optional[asyncio.AbstractEventLoop] = None

def init_jobs(middleware: Middleware, loop: asyncio.AbstractEventLoop):
    """
    初始化 jobs 模块，传入 middleware 的实例和主事件循环。
    这个函数应该在程序启动时被调用一次。
    """
    global _middleware_instance, _main_loop
    _middleware_instance = middleware
    _main_loop = loop

def send_command_job(command: str):
    """
    发送指令的任务。
    这个函数现在只接收 command 作为参数，它会使用全局保存的实例和事件循环。
    :param command: 要发送的指令
    """
    if not _middleware_instance or not _main_loop:
        print("错误：Jobs 模块未初始化，无法发送指令。")
        return

    message = {
        "post_type": "message",
        "message_type": "private",
        "user_id": "10000",  # 模拟一个系统用户
        "message": command,
        "sender": {"nickname": "系统"},
        "platform": "internal"
    }
    
    # 使用 run_coroutine_threadsafe 将协程安全地提交到主事件循环
    asyncio.run_coroutine_threadsafe(_middleware_instance.process_message(message), _main_loop)
