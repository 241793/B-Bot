"""
Automan Framework
一个类似傻妞机器人和AutMan的机器人框架
"""