"""
规则引擎
基于正则表达式或关键词的消息匹配与分发
"""
import re
import asyncio
from typing import Dict, Any, List, Callable, Union
from utils.logger import get_logger
from storage.bucket import BucketManager

class Rule:
    """
    规则类，定义单个匹配规则
    """
    
    def __init__(self, 
                 name: str, 
                 pattern: Union[str, re.Pattern], 
                 handler: Callable, 
                 rule_type: str = "regex",
                 priority: int = 0,
                 description: str = "",
                 source: str = "plugin"): # 新增 source 字段
        """
        初始化规则
        :param name: 规则名称
        :param pattern: 匹配模式（正则表达式或关键词）
        :param handler: 处理函数
        :param rule_type: 规则类型（regex或keyword）
        :param priority: 优先级（数字越大优先级越高）
        :param description: 规则描述
        :param source: 规则来源 ('plugin' 或 'manual')
        """
        self.name = name
        self.pattern = pattern
        self.handler = handler
        self.rule_type = rule_type
        self.priority = priority
        self.description = description
        self.source = source
        self.logger = get_logger(f"rule.{name}")
        
        # 编译正则表达式
        if rule_type == "regex" and isinstance(pattern, str):
            self.compiled_pattern = re.compile(pattern, re.IGNORECASE)
        elif isinstance(pattern, re.Pattern):
            self.compiled_pattern = pattern
        else:
            self.compiled_pattern = pattern

class RuleEngine:
    """
    规则引擎，负责消息匹配和分发
    """
    
    def __init__(self, bucket_manager: BucketManager):
        """
        初始化规则引擎
        :param bucket_manager: 桶管理器实例
        """
        self.rules: List[Rule] = []
        self.bucket_manager = bucket_manager
        self.logger = get_logger("rule_engine")
        self._load_manual_rules()
        
    def _load_manual_rules(self):
        """从桶中加载手动添加的规则（同步版本，仅用于初始化）"""
        manual_rules = self.bucket_manager.get_sync('rule_engine', 'manual_rules', default={})
        for name, rule_data in manual_rules.items():
            rule = Rule(
                name=name,
                pattern=rule_data['pattern'],
                handler=self._create_reply_handler(rule_data['reply']),
                rule_type=rule_data['rule_type'],
                priority=rule_data.get('priority', 0),
                description=rule_data.get('description', ''),
                source='manual'
            )
            # 直接添加到列表，不触发异步保存
            self.rules.append(rule)
        self.rules.sort(key=lambda r: r.priority, reverse=True)
        self.logger.info(f"加载了 {len(manual_rules)} 条手动规则。")

    def _create_reply_handler(self, reply_content: str) -> Callable:
        """为手动规则动态创建回复处理器"""
        def handler(msg, mw):
            return {"content": reply_content}
        return handler

    async def add_rule(self, rule: Rule, save: bool = True):
        """
        添加规则 (异步)
        :param rule: 规则实例
        :param save: 是否保存到桶（仅对'manual'规则有效）
        """
        if any(r.name == rule.name for r in self.rules):
            self.logger.warning(f"规则 {rule.name} 已存在，跳过添加。")
            return

        self.rules.append(rule)
        self.rules.sort(key=lambda r: r.priority, reverse=True)
        self.logger.info(f"规则 {rule.name} 已添加 - {rule.description}")

        if rule.source == 'manual' and save:
            manual_rules = await self.bucket_manager.get('rule_engine', 'manual_rules', default={})
            manual_rules[rule.name] = {
                'pattern': rule.pattern,
                'reply': rule.handler({}, None)['content'],
                'rule_type': rule.rule_type,
                'priority': rule.priority,
                'description': rule.description
            }
            await self.bucket_manager.set('rule_engine', 'manual_rules', manual_rules)

    async def remove_rule(self, rule_name: str) -> bool:
        """
        移除规则 (异步)
        :param rule_name: 规则名称
        :return: 是否成功移除
        """
        rule_to_remove = next((r for r in self.rules if r.name == rule_name), None)
        if not rule_to_remove:
            return False

        self.rules = [r for r in self.rules if r.name != rule_name]
        self.logger.info(f"规则 {rule_name} 已移除")

        if rule_to_remove.source == 'manual':
            manual_rules = await self.bucket_manager.get('rule_engine', 'manual_rules', default={})
            if rule_name in manual_rules:
                del manual_rules[rule_name]
                await self.bucket_manager.set('rule_engine', 'manual_rules', manual_rules)
        
        return True
    
    def match_message(self, message: Dict[str, Any]) -> List[Rule]:
        """
        匹配消息到规则
        :param message: 消息数据
        :return: 匹配的规则列表
        """
        matched_rules = []
        content = message.get("content", "")
        
        for rule in self.rules:
            try:
                if rule.rule_type == "regex":
                    if re.search(rule.pattern, content, re.IGNORECASE):
                        matched_rules.append(rule)
                elif rule.rule_type == "keyword":
                    if rule.pattern.lower() in content.lower():
                        matched_rules.append(rule)
                elif rule.rule_type == "fullmatch":
                    if rule.pattern == content:
                        matched_rules.append(rule)
            except Exception as e:
                self.logger.error(f"匹配规则 {rule.name} 时发生错误: {e}")
        
        return matched_rules
    
    async def process_message(self, message: Dict[str, Any], middleware) -> List[Any]:
        """
        处理消息，执行匹配的规则
        :param message: 消息数据
        :param middleware: 中间件实例
        :return: 所有规则处理器的返回值列表
        """
        matched_rules = self.match_message(message)
        results = []
        
        for rule in matched_rules:
            try:
                if asyncio.iscoroutinefunction(rule.handler):
                    result = await rule.handler(message, middleware)
                else:
                    result = rule.handler(message, middleware)
                
                if result is not None:
                    results.append(result)
                    self.logger.info(f"规则 {rule.name} 处理完成")
                else:
                    self.logger.debug(f"规则 {rule.name} 未返回结果")
                    
            except Exception as e:
                self.logger.error(f"执行规则 {rule.name} 时发生错误: {e}")
        
        return results
    
    def get_rules_by_type(self, rule_type: str) -> List[Rule]:
        return [rule for rule in self.rules if rule.rule_type == rule_type]
    
    async def clear_rules(self):
        self.rules = [r for r in self.rules if r.source != 'manual']
        self.logger.info("所有手动规则已清空")
        await self.bucket_manager.set('rule_engine', 'manual_rules', {})