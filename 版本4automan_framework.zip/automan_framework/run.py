"""
Automan Framework 启动脚本
"""
import asyncio
import sys
import os

# 添加项目根目录到Python路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# 直接从main模块导入内容
from main import main


if __name__ == "__main__":
    print("启动 Automan Framework...")
    print("这是一个类似傻妞机器人和AutMan的机器人框架")
    print("功能包括：多协议接入、插件化架构、规则引擎、持久化存储、可视化面板等")
    print("-" * 50)
    
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n框架已停止")
    except Exception as e:
        print(f"框架运行出错: {e}")
        sys.exit(1)