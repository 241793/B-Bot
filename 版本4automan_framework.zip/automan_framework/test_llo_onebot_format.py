import asyncio
import websockets
import json


async def send_llo_onebot_test_message():
    # 模拟LLOneBot插件可能发送的消息格式
    message = {
        "time": 1703225912,
        "self_id": 3599198670,  # 机器人QQ号
        "post_type": "message",
        "message_type": "group",  # 或 "private"
        "sub_type": "normal",
        "message_id": -123456,
        "group_id": 123456789,
        "user_id": 987654321,
        "anonymous": None,
        "message": "你好",
        "raw_message": "你好",
        "font": 0,
        "sender": {
            "user_id": 987654321,
            "nickname": "测试用户",
            "card": "",
            "sex": "unknown",
            "age": 0,
            "area": "",
            "level": "",
            "role": "member",
            "title": ""
        }
    }
    
    try:
        async with websockets.connect('ws://127.0.0.1:8084') as websocket:  # 使用LLOneBot端口
            await websocket.send(json.dumps(message, ensure_ascii=False))
            print(f"已发送LLOneBot格式消息到框架: {message['message']}")
            
            # 等待一段时间以查看响应
            await asyncio.sleep(5)
    except Exception as e:
        print(f"连接失败: {e}")


if __name__ == "__main__":
    asyncio.run(send_llo_onebot_test_message())