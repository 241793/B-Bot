"""
日志工具
提供统一的日志记录功能
"""
import logging
import os
from datetime import datetime
from logging.handlers import RotatingFileHandler
import collections

# 用于存储日志的全局队列
log_queue = collections.deque(maxlen=100)

class QueueHandler(logging.Handler):
    """
    一个将日志记录到队列中的处理器
    """
    def __init__(self, queue):
        super().__init__()
        self.queue = queue

    def emit(self, record):
        self.queue.append(self.format(record))

def get_logger(name: str, level: int = logging.INFO) -> logging.Logger:
    """
    获取日志记录器
    :param name: 日志记录器名称
    :param level: 日志级别
    :return: 日志记录器实例
    """
    # 创建logger
    logger = logging.getLogger(name)
    logger.setLevel(level)
    
    # 避免重复添加处理器
    if logger.handlers:
        return logger
    
    # 创建格式器
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    
    # 创建控制台处理器
    console_handler = logging.StreamHandler()
    console_handler.setLevel(level)
    console_handler.setFormatter(formatter)
    
    # 创建文件处理器（带轮转）
    log_dir = "logs"
    os.makedirs(log_dir, exist_ok=True)
    
    log_file = os.path.join(log_dir, f"{datetime.now().strftime('%Y%m%d')}.log")
    file_handler = RotatingFileHandler(
        log_file, 
        maxBytes=10*1024*1024,  # 10MB
        backupCount=5,
        encoding='utf-8'
    )
    file_handler.setLevel(level)
    file_handler.setFormatter(formatter)
    
    # 创建队列处理器
    queue_handler = QueueHandler(log_queue)
    queue_handler.setLevel(level)
    queue_handler.setFormatter(formatter)
    
    # 添加处理器到logger
    logger.addHandler(console_handler)
    logger.addHandler(file_handler)
    logger.addHandler(queue_handler)
    
    return logger


def setup_global_logger(level: int = logging.INFO):
    """
    设置全局日志配置
    :param level: 日志级别
    """
    logging.basicConfig(
        level=level,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )


# 预定义的日志记录器
root_logger = get_logger("automan")