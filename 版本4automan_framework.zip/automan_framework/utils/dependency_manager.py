"""
Dependency Manager
用于管理Python依赖包，执行pip命令。
"""
import subprocess
import sys
import json
from .logger import get_logger

logger = get_logger("dependency_manager")

def run_pip_command(command: list) -> dict:
    """
    执行pip命令并返回结果。

    :param command: 要执行的pip命令列表，例如 ['install', 'requests']
    :return: 一个包含成功/失败状态和输出信息的字典
    """
    # 使用 sys.executable 确保我们用的是当前Python环境的pip
    pip_command = [sys.executable, '-m', 'pip'] + command
    logger.info(f"正在执行pip命令: {' '.join(pip_command)}")
    
    try:
        # 使用 subprocess.run 来执行命令
        result = subprocess.run(
            pip_command,
            capture_output=True,
            text=True,
            check=False,  # 我们自己检查返回码
            encoding='utf-8'
        )
        
        if result.returncode == 0:
            logger.info(f"Pip命令成功: {' '.join(pip_command)}")
            return {"success": True, "output": result.stdout}
        else:
            logger.error(f"Pip命令失败: {' '.join(pip_command)}. 错误: {result.stderr}")
            return {"success": False, "output": result.stderr}
            
    except FileNotFoundError:
        logger.error("pip命令未找到。请确保pip已安装并配置在系统路径中。")
        return {"success": False, "output": "pip命令未找到。"}
    except Exception as e:
        logger.error(f"执行pip命令时发生未知错误: {e}")
        return {"success": False, "output": str(e)}

def list_packages() -> dict:
    """
    列出所有已安装的Python包。
    """
    result = run_pip_command(['list', '--format=json'])
    if result["success"]:
        try:
            packages = json.loads(result["output"])
            return {"success": True, "packages": packages}
        except json.JSONDecodeError:
            return {"success": False, "output": "无法解析pip list的输出。"}
    return result

def install_package(package_name: str, index_url: str = None) -> dict:
    """
    安装一个Python包。

    :param package_name: 要安装的包名。
    :param index_url: (可选) Pip的镜像源地址。
    """
    if not package_name or not isinstance(package_name, str):
        return {"success": False, "output": "无效的包名。"}
        
    command = ['install', package_name]
    if index_url and 'pypi.org' not in index_url: # 简单的判断，避免重复添加官方源
        command.extend(['-i', index_url])
        
    return run_pip_command(command)

def uninstall_package(package_name: str) -> dict:
    """
    卸载一个Python包。

    :param package_name: 要卸载的包名。
    """
    if not package_name or not isinstance(package_name, str):
        return {"success": False, "output": "无效的包名。"}
        
    return run_pip_command(['uninstall', package_name, '-y'])
