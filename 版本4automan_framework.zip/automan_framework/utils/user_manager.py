"""
User Management
处理用户创建、验证和存储。
"""
from werkzeug.security import generate_password_hash, check_password_hash
from storage.bucket import BucketManager

# 我们将用户信息存储在 'system' 桶中，使用一个固定的键
USER_STORAGE_KEY = "framework_admin_user"

async def get_user_data(bucket_manager: BucketManager) -> dict:
    """获取存储的用户数据"""
    return await bucket_manager.get("system", USER_STORAGE_KEY)

async def user_exists(bucket_manager: BucketManager) -> bool:
    """检查是否存在任何用户"""
    user_data = await get_user_data(bucket_manager)
    return user_data is not None

async def create_user(bucket_manager: BucketManager, username: str, password: str) -> bool:
    """
    创建一个新用户，并存储哈希后的密码。
    :return: 如果创建成功返回 True，如果用户已存在则返回 False。
    """
    if await user_exists(bucket_manager):
        return False
    
    hashed_password = generate_password_hash(password)
    user_data = {
        "username": username,
        "password_hash": hashed_password
    }
    await bucket_manager.set("system", USER_STORAGE_KEY, user_data)
    return True

async def verify_user(bucket_manager: BucketManager, username: str, password: str) -> bool:
    """
    验证用户名和密码是否正确。
    """
    user_data = await get_user_data(bucket_manager)
    if not user_data or user_data.get("username") != username:
        return False
    
    return check_password_hash(user_data.get("password_hash"), password)
