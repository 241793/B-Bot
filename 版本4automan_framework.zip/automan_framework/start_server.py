"""
Automan Framework 启动脚本
提供便捷的启动方式和配置选项
"""
import os
import sys
import asyncio
import argparse
from main import main as framework_main


def main():
    """
    启动框架的主函数
    """
    parser = argparse.ArgumentParser(description='Automan Framework 启动器')
    parser.add_argument('--ws-host', default='0.0.0.0', help='WebSocket服务器主机地址 (默认: 0.0.0.0)')
    parser.add_argument('--ws-port', type=int, default=8080, help='WebSocket服务器端口 (默认: 8080)')
    parser.add_argument('--web-host', default='0.0.0.0', help='Web界面主机地址 (默认: 0.0.0.0)')
    parser.add_argument('--web-port', type=int, default=5000, help='Web界面端口 (默认: 5000)')
    parser.add_argument('--plugins-dir', default='plugins', help='插件目录 (默认: plugins)')
    parser.add_argument('--debug', action='store_true', help='启用调试模式')
    
    args = parser.parse_args()
    
    # 设置环境变量
    os.environ['WS_HOST'] = args.ws_host
    os.environ['WS_PORT'] = str(args.ws_port)
    os.environ['WEB_UI_HOST'] = args.web_host
    os.environ['WEB_UI_PORT'] = str(args.web_port)
    os.environ['PLUGINS_DIR'] = args.plugins_dir
    os.environ['DEBUG'] = 'true' if args.debug else 'false'
    
    print(f"🚀 启动 Automan Framework...")
    print(f"🌐 WebSocket服务器: ws://{args.ws_host}:{args.ws_port}")
    print(f"🌐 Web管理界面: http://{args.web_host}:{args.web_port}")
    print(f"📦 插件目录: {args.plugins_dir}")
    print(f"⚙️  调试模式: {'启用' if args.debug else '禁用'}")
    print("-" * 50)
    
    try:
        # 运行框架
        asyncio.run(framework_main())
    except KeyboardInterrupt:
        print("\n👋 框架已停止")
    except Exception as e:
        print(f"\n❌ 启动失败: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()