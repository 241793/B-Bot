"""
测试Automan框架的基本功能
"""
import asyncio
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# 使用绝对导入路径
from storage.bucket import BucketManager
from middleware.middleware import Middleware
from plugins.plugin_manager import PluginManager
from rule_engine.rule_engine import RuleEngine
from adapters.websocket_adapter import WebSocketAdapter
from config import config
from utils.logger import get_logger


async def test_framework():
    """
    测试框架的基本功能
    """
    print("开始测试 Automan Framework...")
    
    # 测试存储功能
    print("\n1. 测试存储功能...")
    bucket_manager = BucketManager("test_data")
    await bucket_manager.set("test_bucket", "test_key", "test_value")
    value = await bucket_manager.get("test_bucket", "test_key")
    print(f"存储测试: {value}")
    
    # 测试中间件
    print("\n2. 测试中间件功能...")
    middleware = Middleware(bucket_manager)
    
    # 测试插件管理器
    print("\n3. 测试插件管理器...")
    plugin_manager = PluginManager(middleware, "plugins")
    print(f"插件目录: {plugin_manager.plugins_dir}")
    
    # 测试规则引擎
    print("\n4. 测试规则引擎...")
    rule_engine = RuleEngine()
    print(f"初始规则数量: {len(rule_engine.rules)}")
    
    # 测试配置
    print("\n5. 测试配置...")
    print(f"WebSocket URL: {config.ws_url}")
    print(f"Web UI 端口: {config.web_ui_port}")
    
    # 测试日志
    print("\n6. 测试日志功能...")
    logger = get_logger("test")
    logger.info("这是一个测试日志")
    
    print("\n框架测试完成！")


if __name__ == "__main__":
    asyncio.run(test_framework())