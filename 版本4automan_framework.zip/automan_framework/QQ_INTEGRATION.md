# Automan Framework 与 QQ 集成指南

本文档说明如何将 Automan Framework 与 QQ 平台集成，实现消息的接收和回复。

## 架构说明

Automan Framework 使用双WebSocket服务器架构：

1. **主WebSocket服务器** (端口 8080)
   - 用于接收来自QQ等平台的消息
   - 由 `WebSocketServerAdapter` 管理

2. **反向WebSocket服务器** (端口 8081)
   - 用于将框架处理结果发送回QQ等平台
   - 由 `ReverseWebSocketAdapter` 管理

## 配置方式

### 方式1：使用 OneBot 协议的机器人框架

如果你使用的是支持 OneBot 协议的QQ机器人框架（如 go-cqhttp、Mirai、NoneBot 等），可以按以下方式配置：

#### 配置 OneBot 框架连接到 Automan Framework

在 OneBot 框架中配置正向 WebSocket 连接：

```json
{
  "servers": [
    {
      "ws_reverse": {
        "url": "ws://your_server_ip:8080",  // 连接到 Automan Framework 接收消息
        "reverse_url": "ws://your_server_ip:8081",  // 用于 Automan Framework 发送消息回来
        "enable": true
      }
    }
  ]
}
```

### 方式2：直接配置

如果您的QQ机器人框架支持直接配置WebSocket连接：

#### 接收QQ消息到框架
- WebSocket连接地址: `ws://your_server_ip:8080`
- 连接后QQ机器人框架的消息将发送到此端口，由框架处理

#### 框架发送消息回QQ
- 反向WebSocket连接地址: `ws://your_server_ip:8081`
- 框架处理完消息后的回复将发送到此端口，由QQ机器人框架接收并发送给用户

## 消息格式

### 发送到框架的消息格式
```json
{
  "id": "消息唯一ID",
  "type": "message",
  "content": "消息内容",
  "user_id": "用户ID",
  "group_id": "群ID（可选）",
  "timestamp": "时间戳",
  "raw_message": "原始消息"
}
```

### 框架发送的回复消息格式
```json
{
  "action": "send_private_msg",  // 或 "send_group_msg"
  "params": {
    "user_id": "目标用户ID",
    "group_id": "目标群ID", 
    "message": "回复内容"
  }
}
```

## 验证配置

### 1. 检查服务启动状态
```bash
# 启动框架
python start_server.py --ws-port 8080 --web-port 5000
```

应该看到以下日志：
```
WebSocket服务器已启动在 0.0.0.0:8080
反向WebSocket服务器已启动在 0.0.0.0:8081
```

### 2. 测试连接
```bash
# 测试主WebSocket服务器（接收消息）
python test_ws_client.py

# 测试反向WebSocket服务器（发送消息）
python simulate_qq_client.py
```

### 3. 检查API状态
```bash
curl http://127.0.0.1:5000/api/status
```

## 故障排除

### 问题1：QQ收不到回复消息
- **可能原因**: 反向WebSocket连接未建立
- **解决方案**: 
  1. 确认QQ机器人框架已连接到 `ws://your_server_ip:8081`
  2. 检查防火墙是否阻止8081端口
  3. 查看框架日志中是否有发送消息的记录

### 问题2：框架收不到QQ消息
- **可能原因**: 正向WebSocket连接未建立
- **解决方案**:
  1. 确认QQ机器人框架已连接到 `ws://your_server_ip:8080`
  2. 检查防火墙是否阻止8080端口
  3. 验证消息格式是否符合框架要求

### 问题3：连接被拒绝
- **可能原因**: IP地址或端口配置错误
- **解决方案**: 
  1. 确认服务器IP地址正确
  2. 检查端口是否被其他服务占用
  3. 验证防火墙设置

## 配置示例

### go-cqhttp 配置示例
在 `config.yml` 中：
```yaml
servers:
  - ws-reverse:
      universal: ws://your_server_ip:8080
      api: ws://your_server_ip:8081/api
      event: ws://your_server_ip:8081/event
```

### NoneBot 配置示例
在 `.env` 文件中：
```
HOST=0.0.0.0
PORT=8082
WS_HOST=your_server_ip
WS_PORT=8080  # 连接到 Automan Framework
REVERSE_WS_HOST=your_server_ip
REVERSE_WS_PORT=8081  # Automan Framework 发送消息回来
```

## 安全注意事项

1. **IP白名单**: 在生产环境中，建议配置IP白名单限制访问
2. **身份验证**: 可以在WebSocket连接中添加身份验证机制
3. **数据加密**: 建议使用 WSS (WebSocket Secure) 进行加密传输
4. **访问控制**: 限制对管理端口的访问权限

## 性能调优

1. **连接池**: 根据预期的并发量调整连接池大小
2. **消息队列**: 对于高并发场景，可考虑引入消息队列
3. **负载均衡**: 在多实例部署时使用负载均衡器

## 扩展功能

框架支持以下扩展功能：

1. **多平台支持**: 可以同时连接多个平台（QQ、微信、Telegram等）
2. **插件热加载**: 支持在线修改和加载插件
3. **规则引擎**: 支持复杂的规则匹配和处理
4. **Web管理界面**: 提供完整的管理功能