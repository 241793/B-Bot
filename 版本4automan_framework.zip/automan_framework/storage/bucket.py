"""
桶存储管理器
实现持久化存储功能，类似AutMan的桶(bucket)概念
"""
import json
import asyncio
import os
from typing import Any, Dict, List
from pathlib import Path
import logging

class BucketManager:
    """
    桶管理器，实现持久化存储功能
    支持层级分明的配置信息、用户权限、插件数据存储
    """
    
    def __init__(self, data_dir: str = "data"):
        """
        初始化桶管理器
        :param data_dir: 数据存储目录
        """
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(exist_ok=True)
        self.buckets: Dict[str, Dict[str, Any]] = {}
        self.locks: Dict[str, asyncio.Lock] = {}
        self._dict_lock = asyncio.Lock()  # 用于保护buckets和locks字典本身
        
        self.logger = logging.getLogger("bucket_manager")
        if not self.logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
            handler.setFormatter(formatter)
            self.logger.addHandler(handler)
            self.logger.setLevel(logging.INFO)
        
        self._load_all_buckets()
    
    def _get_bucket_file_path(self, bucket_name: str) -> Path:
        return self.data_dir / f"{bucket_name}.json"
    
    def _load_all_buckets(self):
        for file_path in self.data_dir.glob("*.json"):
            bucket_name = file_path.stem
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    self.buckets[bucket_name] = json.load(f)
                self.logger.info(f"桶 {bucket_name} 已加载")
            except Exception as e:
                self.logger.error(f"加载桶 {bucket_name} 失败: {e}")

    async def _get_or_create_lock(self, bucket_name: str) -> asyncio.Lock:
        async with self._dict_lock:
            if bucket_name not in self.locks:
                self.locks[bucket_name] = asyncio.Lock()
            return self.locks[bucket_name]

    async def _save_bucket(self, bucket_name: str):
        if bucket_name not in self.buckets:
            return
        
        file_path = self._get_bucket_file_path(bucket_name)
        loop = asyncio.get_running_loop()
        
        def save_to_file():
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(self.buckets[bucket_name], f, ensure_ascii=False, indent=2)
        
        try:
            await loop.run_in_executor(None, save_to_file)
        except Exception as e:
            self.logger.error(f"保存桶 {bucket_name} 失败: {e}")

    async def create_bucket(self, bucket_name: str) -> bool:
        """
        创建一个新的空桶
        :param bucket_name: 桶名称
        :return: 如果创建成功返回True，如果已存在返回False
        """
        async with self._dict_lock:
            if bucket_name in self.buckets:
                return False
            self.buckets[bucket_name] = {}
        
        lock = await self._get_or_create_lock(bucket_name)
        async with lock:
            await self._save_bucket(bucket_name)
            self.logger.info(f"桶 {bucket_name} 已创建")
        return True

    async def get(self, bucket_name: str, key: str, default=None) -> Any:
        lock = await self._get_or_create_lock(bucket_name)
        async with lock:
            bucket = self.buckets.get(bucket_name, {})
            return bucket.get(key, default)

    def get_sync(self, bucket_name: str, key: str, default=None) -> Any:
        bucket = self.buckets.get(bucket_name, {})
        return bucket.get(key, default)

    async def set(self, bucket_name: str, key: str, value: Any):
        lock = await self._get_or_create_lock(bucket_name)
        async with lock:
            async with self._dict_lock:
                if bucket_name not in self.buckets:
                    self.buckets[bucket_name] = {}
            
            self.buckets[bucket_name][key] = value
            await self._save_bucket(bucket_name)
            self.logger.debug(f"桶 {bucket_name} 中的键 {key} 已设置")

    async def delete(self, bucket_name: str, key: str):
        lock = await self._get_or_create_lock(bucket_name)
        async with lock:
            if bucket_name in self.buckets and key in self.buckets[bucket_name]:
                del self.buckets[bucket_name][key]
                await self._save_bucket(bucket_name)
                self.logger.debug(f"桶 {bucket_name} 中的键 {key} 已删除")

    async def keys(self, bucket_name: str) -> List[str]:
        lock = await self._get_or_create_lock(bucket_name)
        async with lock:
            return list(self.buckets.get(bucket_name, {}).keys())

    async def clear(self, bucket_name: str):
        lock = await self._get_or_create_lock(bucket_name)
        async with lock:
            self.buckets[bucket_name] = {}
            await self._save_bucket(bucket_name)
            self.logger.info(f"桶 {bucket_name} 已清空")

    async def bucket_exists(self, bucket_name: str) -> bool:
        async with self._dict_lock:
            return bucket_name in self.buckets

    async def list_buckets(self) -> List[str]:
        async with self._dict_lock:
            return list(self.buckets.keys())

    async def get_bucket_size(self, bucket_name: str) -> int:
        lock = await self._get_or_create_lock(bucket_name)
        async with lock:
            return len(self.buckets.get(bucket_name, 0))

    async def update(self, bucket_name: str, data: Dict[str, Any]):
        lock = await self._get_or_create_lock(bucket_name)
        async with lock:
            async with self._dict_lock:
                if bucket_name not in self.buckets:
                    self.buckets[bucket_name] = {}
            
            self.buckets[bucket_name].update(data)
            await self._save_bucket(bucket_name)
            self.logger.info(f"桶 {bucket_name} 已更新")

    async def get_all(self, bucket_name: str) -> Dict[str, Any]:
        lock = await self._get_or_create_lock(bucket_name)
        async with lock:
            return self.buckets.get(bucket_name, {}).copy()

class Bucket:
    """
    桶类，提供更便捷的桶操作接口
    """
    def __init__(self, bucket_manager: BucketManager, name: str):
        self.bucket_manager = bucket_manager
        self.name = name
    
    async def get(self, key: str, default=None) -> Any:
        return await self.bucket_manager.get(self.name, key, default)
    
    async def set(self, key: str, value: Any):
        await self.bucket_manager.set(self.name, key, value)
    
    async def delete(self, key: str):
        await self.bucket_manager.delete(self.name, key)
    
    async def keys(self) -> List[str]:
        return await self.bucket_manager.keys(self.name)
    
    async def clear(self):
        await self.bucket_manager.clear(self.name)
    
    async def update(self, data: Dict[str, Any]):
        await self.bucket_manager.update(self.name, data)
    
    async def get_all(self) -> Dict[str, Any]:
        return await self.bucket_manager.get_all(self.name)
    
    async def size(self) -> int:
        return await self.bucket_manager.get_bucket_size(self.name)