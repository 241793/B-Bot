"""
Automan Framework 集成测试
测试QQ集成的完整消息流
"""
import asyncio
import websockets
import json
import uuid
from datetime import datetime
import time
import os


async def test_message_flow():
    """
    测试完整的消息流：
    1. 发送消息到框架 (端口8080)
    2. 框架处理消息
    3. 框架发送回复到反向WebSocket (端口8081)
    """
    print("🧪 开始集成测试：完整消息流")
    print("="*60)
    
    # 获取端口配置
    ws_port = int(os.getenv('WS_PORT', '8080'))
    reverse_ws_port = int(os.getenv('REVERSE_WS_PORT', '8081'))
    
    # 用于存储接收到的回复
    received_responses = []
    
    # 启动反向WebSocket客户端来接收回复
    async def reverse_ws_client():
        try:
            async with websockets.connect(f"ws://localhost:{reverse_ws_port}") as websocket:
                print(f"✅ 连接到反向WebSocket服务器 (端口{reverse_ws_port})")
                
                # 接收来自框架的回复
                async for message in websocket:
                    try:
                        data = json.loads(message)
                        received_responses.append(data)
                        print(f"📥 接收到框架回复: {data}")
                    except json.JSONDecodeError:
                        print(f"📥 接收到非JSON回复: {message}")
        except Exception as e:
            print(f"❌ 反向WebSocket连接失败: {e}")
    
    # 启动反向WebSocket客户端任务
    reverse_task = asyncio.create_task(reverse_ws_client())
    
    # 等待连接建立
    await asyncio.sleep(1)
    
    # 发送消息到框架
    try:
        async with websockets.connect(f"ws://localhost:{ws_port}") as websocket:
            print(f"✅ 连接到框架WebSocket服务器 (端口{ws_port})")
            
            # 发送测试消息
            test_messages = [
                {
                    "id": str(uuid.uuid4()),
                    "type": "message", 
                    "content": "你好",
                    "user_id": "test_user_123",
                    "group_id": "test_group_456",
                    "timestamp": datetime.now().isoformat(),
                    "raw_message": "你好"
                },
                {
                    "id": str(uuid.uuid4()),
                    "type": "message",
                    "content": "复读 这是个复读测试",
                    "user_id": "test_user_123",
                    "group_id": "test_group_456", 
                    "timestamp": datetime.now().isoformat(),
                    "raw_message": "复读 这是个复读测试"
                }
            ]
            
            for msg in test_messages:
                await websocket.send(json.dumps(msg, ensure_ascii=False))
                print(f"📤 发送消息到框架: {msg['content']}")
                
                # 等待回复
                await asyncio.sleep(2)
        
        # 等待一些时间以接收可能的回复
        await asyncio.sleep(5)
        
    except Exception as e:
        print(f"❌ 连接框架WebSocket失败: {e}")
    
    # 取消反向WebSocket任务
    reverse_task.cancel()
    
    print("="*60)
    print(f"📊 测试结果:")
    print(f"   发送消息数: 2")
    print(f"   接收回复数: {len(received_responses)}")
    
    if len(received_responses) > 0:
        print("✅ 消息流测试通过！框架能够接收消息并发送回复")
        for i, resp in enumerate(received_responses):
            print(f"   回复 {i+1}: {resp}")
        return True
    else:
        print("❌ 消息流测试失败！未接收到框架回复")
        return False


async def test_api_endpoints():
    """
    测试API端点
    """
    import requests
    
    print("\n🧪 开始API端点测试")
    print("="*60)
    
    web_port = int(os.getenv('WEB_UI_PORT', '5000'))
    base_url = f"http://127.0.0.1:{web_port}"
    success_count = 0
    total_tests = 5
    
    # 测试状态API
    try:
        response = requests.get(f"{base_url}/api/status", timeout=5)
        if response.status_code == 200:
            print("✅ 状态API测试通过")
            success_count += 1
        else:
            print(f"❌ 状态API测试失败: {response.status_code}")
    except Exception as e:
        print(f"❌ 状态API测试异常: {e}")
    
    # 测试插件API
    try:
        response = requests.get(f"{base_url}/api/plugins", timeout=5)
        if response.status_code == 200:
            print("✅ 插件API测试通过")
            success_count += 1
        else:
            print(f"❌ 插件API测试失败: {response.status_code}")
    except Exception as e:
        print(f"❌ 插件API测试异常: {e}")
    
    # 测试规则API
    try:
        response = requests.get(f"{base_url}/api/rules", timeout=5)
        if response.status_code == 200:
            print("✅ 规则API测试通过")
            success_count += 1
        else:
            print(f"❌ 规则API测试失败: {response.status_code}")
    except Exception as e:
        print(f"❌ 规则API测试异常: {e}")
    
    # 测试适配器API
    try:
        response = requests.get(f"{base_url}/api/adapters", timeout=5)
        if response.status_code == 200:
            print("✅ 适配器API测试通过")
            success_count += 1
        else:
            print(f"❌ 适配器API测试失败: {response.status_code}")
    except Exception as e:
        print(f"❌ 适配器API测试异常: {e}")
    
    # 测试日志API
    try:
        response = requests.get(f"{base_url}/api/logs", timeout=5)
        if response.status_code == 200:
            print("✅ 日志API测试通过")
            success_count += 1
        else:
            print(f"❌ 日志API测试失败: {response.status_code}")
    except Exception as e:
        print(f"❌ 日志API测试异常: {e}")
    
    print(f"📊 API测试结果: {success_count}/{total_tests} 通过")
    return success_count == total_tests


async def run_integration_tests():
    """
    运行集成测试
    """
    print("🚀 Automan Framework 集成测试开始")
    print("="*60)
    
    success_count = 0
    total_tests = 2
    
    # 测试消息流
    if await test_message_flow():
        success_count += 1
    
    # 测试API端点
    if await test_api_endpoints():
        success_count += 1
    
    print("\n" + "="*60)
    print(f"🏁 集成测试完成: {success_count}/{total_tests} 测试通过")
    
    if success_count == total_tests:
        print("🎉 所有集成测试通过！Automan Framework 运行正常。")
        print("\n📋 集成状态:")
        print("   ✅ 消息接收: 可以从WebSocket接收消息")
        print("   ✅ 消息处理: 框架能够处理消息")
        print("   ✅ 消息回复: 框架能够发送回复到反向WebSocket")
        print("   ✅ API服务: 所有API端点正常工作")
        print("   ✅ QQ集成: 可以与QQ平台集成")
        return True
    else:
        print("❌ 部分集成测试失败！")
        return False


if __name__ == "__main__":
    try:
        asyncio.run(run_integration_tests())
    except KeyboardInterrupt:
        print("\n⚠️ 测试被用户中断")
    except Exception as e:
        print(f"\n❌ 测试运行异常: {e}")