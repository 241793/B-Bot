"""
Automan Framework 主应用
一个类似傻妞机器人和AutMan的机器人框架
"""
import asyncio
import signal
import sys
from typing import Dict, Any

from adapters.websocket_adapter import WebSocketAdapter
from adapters.custom_adapter import CustomAdapter
from adapters.reverse_ws_adapter import ReverseWebSocketAdapter
from middleware.middleware import Middleware
from plugins import PluginManager
from rule_engine.rule_engine import Rule, RuleEngine
from storage.bucket import BucketManager
from web_ui.web_app import WebUI
from config import config
from utils.logger import get_logger, setup_global_logger
from scheduler import scheduler
from jobs import init_jobs


class AutomanFramework:
    """
    Automan框架主类
    集成所有组件，提供统一的机器人框架服务
    """
    
    def __init__(self):
        self.logger = get_logger("main")
        self.bucket_manager = BucketManager(config.data_dir)
        self.rule_engine = RuleEngine(self.bucket_manager)
        self.middleware = Middleware(self.bucket_manager)
        
        # 获取当前事件循环并初始化 jobs 模块
        loop = asyncio.get_event_loop()
        init_jobs(self.middleware, loop)

        self.plugin_manager = PluginManager(
            plugins_dir=config.plugins_dir,
            bucket_manager=self.bucket_manager,
            rule_engine=self.rule_engine,
            middleware=self.middleware,
            scheduler=scheduler
        )
        self.web_ui = WebUI(
            self.middleware,
            self.plugin_manager,
            self.rule_engine,
            self.bucket_manager,
            host=config.web_ui_host,
            port=config.web_ui_port
        )

        # 适配器字典
        self.adapters = {}
        self.web_ui_task = None

        # 事件循环
        self.running = False

    async def initialize(self):
        """
        初始化框架
        """
        self.logger.info("正在初始化 Automan Framework...")

        # 初始化存储
        await self._init_storage()

        # 关键改动：先加载插件，让系统指令等插件获得高优先级
        await self._init_plugins()

        # 再初始化规则引擎，使其处理器排在插件后面
        await self._init_rules()

        # 最后初始化适配器
        await self._init_adapters()

        self.logger.info("Automan Framework 初始化完成")

    async def _init_storage(self):
        """
        初始化存储系统
        """
        # 确保系统桶存在
        if not await self.bucket_manager.bucket_exists("system"):
            await self.bucket_manager.set("system", "initialized", True)

        # 设置管理员列表
        if config.admin_users:
            await self.bucket_manager.set("system", "admin_list", config.admin_users)

        self.logger.info("存储系统初始化完成")

    async def _init_adapters(self):
        """
        初始化适配器
        """
        # 初始化WebSocket适配器（用于QQ等平台）- 只有在配置了有效URL时才启用
        if config.ws_url and config.ws_url.strip():
            ws_config = {
                "ws_url": config.ws_url,
                "reconnect_interval": config.reconnect_interval
            }
            websocket_adapter = WebSocketAdapter(ws_config)
            websocket_adapter.message_handler = self.middleware.process_message
            self.middleware.register_adapter("websocket", websocket_adapter)
            self.adapters["websocket"] = websocket_adapter
            self.logger.info(f"WebSocket适配器已配置，连接地址: {config.ws_url}")
        else:
            self.logger.info("WebSocket适配器未配置，跳过初始化")

        # 初始化自定义适配器
        custom_config = {
            "name": "custom",
            "message_handler": self.middleware.process_message,
            "event_handlers": {}
        }
        custom_adapter = CustomAdapter(custom_config)
        self.middleware.register_adapter("custom", custom_adapter)
        self.adapters["custom"] = custom_adapter

        # 初始化反向WebSocket适配器（用于发送和接收消息）
        reverse_ws_config = {
            "host": config.reverse_ws_host,
            "port": config.reverse_ws_port,
            "bucket_manager": self.bucket_manager # 传递 bucket_manager
        }
        reverse_ws_adapter = ReverseWebSocketAdapter(reverse_ws_config)

        reverse_ws_adapter.message_handler = self.middleware.process_message

        self.middleware.register_adapter("reverse_ws", reverse_ws_adapter)
        self.adapters["reverse_ws"] = reverse_ws_adapter

        self.logger.info("适配器初始化完成")

    async def _init_plugins(self):
        """
        初始化插件系统
        """
        await self.plugin_manager.load_all_plugins()
        self.logger.info(f"插件系统初始化完成，共加载 {len(self.plugin_manager.plugins)} 个插件")

    async def _init_rules(self):
        """
        初始化规则引擎并将其作为消息处理器注册
        """
        self.middleware.register_message_handler(self.rule_engine_handler)
        self.logger.info("规则引擎已作为消息处理器注册")

    async def rule_engine_handler(self, message: Dict[str, Any]):
        """
        一个包装了规则引擎的中间件处理器
        """
        results = await self.rule_engine.process_message(message, self.middleware)

        for result in results:
            if result:
                return result

        return None

    async def start(self):
        """
        启动框架
        """
        self.running = True
        self.logger.info("正在启动 Automan Framework...")

        # 启动调度器
        scheduler.start()
        self.logger.info("调度器已启动")

        for name, adapter in self.adapters.items():
            try:
                asyncio.create_task(adapter.connect())
                self.logger.info(f"适配器 {name} 正在启动...")
            except Exception as e:
                self.logger.error(f"适配器 {name} 启动失败: {e}")

        self.web_ui_task = asyncio.create_task(self._run_web_ui())

        self.logger.info(f"Web UI 服务启动在 http://{config.web_ui_host}:{config.web_ui_port}")
        self.logger.info("Automan Framework 启动完成")

        try:
            while self.running:
                await asyncio.sleep(1)
        except asyncio.CancelledError:
            pass
        finally:
            await self.stop()

    async def _run_web_ui(self):
        """
        运行Web UI
        """
        try:
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(None, self.web_ui.run, False)
        except Exception as e:
            self.logger.error(f"Web UI 运行出错: {e}")

    async def stop(self):
        """
        停止框架
        """
        self.logger.info("正在停止 Automan Framework...")

        # 停止调度器
        scheduler.shutdown()
        self.logger.info("调度器已停止")

        if self.web_ui_task:
            self.web_ui_task.cancel()
            try:
                await self.web_ui_task
            except asyncio.CancelledError:
                pass

        for name, adapter in self.adapters.items():
            try:
                await adapter.disconnect()
                self.logger.info(f"适配器 {name} 已停止")
            except Exception as e:
                self.logger.error(f"停止适配器 {name} 时出错: {e}")

        self.running = False
        self.logger.info("Automan Framework 已停止")

    def signal_handler(self, signum, frame):
        """
        信号处理器
        """
        self.logger.info(f"收到信号 {signum}，正在关闭...")
        self.running = False


async def main():
    """
    主函数
    """
    setup_global_logger()

    framework = AutomanFramework()

    await framework.initialize()

    signal.signal(signal.SIGINT, framework.signal_handler)
    signal.signal(signal.SIGTERM, framework.signal_handler)

    try:
        await framework.start()
    except KeyboardInterrupt:
        print("\n收到键盘中断信号，正在关闭...")
        await framework.stop()
    except Exception as e:
        print(f"框架运行出错: {e}")
        await framework.stop()
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())