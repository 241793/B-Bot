"""
自定义消息适配器
用于对接自定义消息平台
"""
import asyncio
import json
from typing import Dict, Any, Optional
from .base_adapter import BaseAdapter


class CustomAdapter(BaseAdapter):
    """
    自定义消息适配器，用于对接自定义消息平台
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        初始化自定义适配器
        :param config: 配置信息
        """
        super().__init__(config)
        self.adapter_name = config.get("name", "custom")
        self.message_handler = config.get("message_handler", None)
        self.event_handlers = config.get("event_handlers", {})
        
    async def connect(self):
        """
        连接到自定义平台
        """
        self.is_running = True
        print(f"自定义适配器 {self.adapter_name} 已连接")
        
    async def disconnect(self):
        """
        断开连接
        """
        self.is_running = False
        print(f"自定义适配器 {self.adapter_name} 已断开")
        
    async def send_message(self, message_data: Dict[str, Any]):
        """
        发送消息
        :param message_data: 消息数据
        """
        # 根据配置的发送方式发送消息
        if self.message_handler:
            await self.message_handler(message_data)
        else:
            print(f"自定义适配器 {self.adapter_name} 发送消息: {message_data}")
    
    def parse_message(self, raw_message: Any) -> Dict[str, Any]:
        """
        解析原始消息
        :param raw_message: 原始消息
        :return: 标准化消息格式
        """
        # 根据配置的解析方式解析消息
        if isinstance(raw_message, str):
            try:
                data = json.loads(raw_message)
            except json.JSONDecodeError:
                data = {"content": raw_message}
        elif isinstance(raw_message, dict):
            data = raw_message
        else:
            data = {"content": str(raw_message)}
        
        # 标准化消息格式
        standardized_message = {
            "platform": self.adapter_name,
            "message_id": data.get("message_id"),
            "user_id": data.get("user_id", "unknown"),
            "group_id": data.get("group_id"),  # 可选
            "sender": data.get("sender", {}),
            "content": data.get("content", ""),
            "raw_data": data,
            "timestamp": data.get("timestamp", asyncio.get_event_loop().time())
        }
        
        return standardized_message