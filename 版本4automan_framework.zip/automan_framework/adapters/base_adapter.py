"""
适配器基类
定义了所有适配器需要实现的接口
"""
from abc import ABC, abstractmethod
from typing import Dict, Any, Optional
import asyncio
import json


class BaseAdapter(ABC):
    """
    适配器基类，定义了所有适配器需要实现的接口
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        初始化适配器
        :param config: 配置信息
        """
        self.config = config
        self.is_running = False
        
    @abstractmethod
    async def connect(self):
        """
        连接到消息平台
        """
        pass
    
    @abstractmethod
    async def disconnect(self):
        """
        断开与消息平台的连接
        """
        pass
    
    @abstractmethod
    async def send_message(self, message_data: Dict[str, Any]):
        """
        发送消息到消息平台
        :param message_data: 消息数据
        """
        pass
    
    @abstractmethod
    def parse_message(self, raw_message: Any) -> Dict[str, Any]:
        """
        解析原始消息为标准化格式
        :param raw_message: 原始消息
        :return: 标准化消息格式
        """
        pass
    
    def format_message(self, content: str, message_type: str = "text", **kwargs) -> Dict[str, Any]:
        """
        格式化消息
        :param content: 消息内容
        :param message_type: 消息类型
        :param kwargs: 其他参数
        :return: 格式化后的消息
        """
        message = {
            "content": content,
            "type": message_type,
            "timestamp": asyncio.get_event_loop().time(),
            **kwargs
        }
        return message