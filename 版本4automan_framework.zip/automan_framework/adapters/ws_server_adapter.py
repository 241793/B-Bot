"""
WebSocket服务器适配器
用于提供WebSocket服务，允许客户端连接并发送消息
"""
import asyncio
import websockets
import json
import logging
from typing import Dict, Any, Optional, Set
from .base_adapter import BaseAdapter


class WebSocketServerAdapter(BaseAdapter):
    """
    WebSocket服务器适配器，提供WebSocket服务给客户端连接
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        初始化WebSocket服务器适配器
        :param config: 配置信息，包括监听地址和端口
        """
        super().__init__(config)
        self.host = config.get("host", "localhost")
        self.port = config.get("port", 8080)
        self.server = None
        self.clients: Set[websockets.WebSocketServerProtocol] = set()
        self.logger = logging.getLogger(__name__)
        
    async def connect(self):
        """
        启动WebSocket服务器
        """
        try:
            self.logger.info(f"正在启动WebSocket服务器在 {self.host}:{self.port}")
            self.server = await websockets.serve(
                self._handle_client_connection,
                self.host,
                self.port
            )
            self.is_running = True
            self.logger.info(f"WebSocket服务器已启动在 {self.host}:{self.port}")
            
            # 保持服务器运行
            await self.server.wait_closed()
        except Exception as e:
            self.logger.error(f"WebSocket服务器启动失败: {e}")
    
    async def disconnect(self):
        """
        关闭WebSocket服务器
        """
        self.is_running = False
        if self.server:
            self.server.close()
            await self.server.wait_closed()
            self.logger.info("WebSocket服务器已关闭")
        
        # 关闭所有客户端连接
        for client in self.clients.copy():
            try:
                await client.close()
            except:
                pass
        self.clients.clear()
    
    async def _handle_client_connection(self, websocket: websockets.WebSocketServerProtocol, path: str):
        """
        处理客户端连接
        :param websocket: WebSocket连接对象
        :param path: 连接路径
        """
        self.logger.info(f"新的WebSocket客户端连接: {websocket.remote_address}")
        self.clients.add(websocket)
        
        try:
            async for message in websocket:
                await self._handle_client_message(websocket, message)
        except websockets.exceptions.ConnectionClosed:
            self.logger.info(f"WebSocket客户端断开连接: {websocket.remote_address}")
        except Exception as e:
            self.logger.error(f"处理客户端消息时出错: {e}")
        finally:
            self.clients.discard(websocket)
    
    async def _handle_client_message(self, websocket: websockets.WebSocketServerProtocol, message: str):
        """
        处理来自客户端的消息
        :param websocket: WebSocket连接对象
        :param message: 接收到的消息
        """
        try:
            # 解析消息
            data = json.loads(message)
            self.logger.info(f"收到客户端消息: {data}")
            
            # 解析为框架标准消息格式
            standardized_message = self.parse_message(data)
            
            # 检查中间件是否存在并处理消息
            if hasattr(self, 'middleware') and self.middleware:
                # 让中间件处理消息，它会负责调用插件和规则并发送响应
                await self.middleware.process_message(standardized_message)
            else:
                # 如果没有中间件，记录错误但不发送响应到原始连接
                self.logger.error("没有配置中间件，无法处理消息")
        
        except json.JSONDecodeError as e:
            self.logger.error(f"解析客户端消息失败: {e}, 消息: {message}")
            # 不发送错误响应到原始连接，因为这可能导致LLOneBot插件问题
        except Exception as e:
            self.logger.error(f"处理客户端消息时出错: {e}")
            # 不发送错误响应到原始连接，因为这可能导致LLOneBot插件问题
    
    def parse_message(self, raw_message: Any) -> Dict[str, Any]:
        """
        解析原始消息为标准格式
        :param raw_message: 原始消息
        :return: 标准化消息格式
        """
        if isinstance(raw_message, str):
            try:
                data = json.loads(raw_message)
            except json.JSONDecodeError:
                data = {"content": raw_message}
        elif isinstance(raw_message, dict):
            data = raw_message
        else:
            data = {"content": str(raw_message)}
        
        # 标准化消息格式
        standardized_message = {
            "platform": "ws_server",
            "message_id": data.get("id"),
            "user_id": str(data.get("user_id", data.get("user", "unknown"))),
            "group_id": data.get("group_id", data.get("group", None)),
            "sender": data.get("sender", {}),
            "content": data.get("content", data.get("message", "")),
            "raw_data": data,
            "timestamp": data.get("timestamp", data.get("time"))
        }
        
        return standardized_message
    
    async def send_to_client(self, websocket: websockets.WebSocketServerProtocol, message_data: Dict[str, Any]):
        """
        发送消息到特定客户端
        :param websocket: WebSocket连接对象
        :param message_data: 消息数据
        """
        try:
            message_json = json.dumps(message_data, ensure_ascii=False)
            await websocket.send(message_json)
            self.logger.info(f"发送消息到客户端: {message_data}")
        except Exception as e:
            self.logger.error(f"发送消息到客户端失败: {e}")
            # 移除断开的客户端
            self.clients.discard(websocket)
    
    async def broadcast_message(self, message_data: Dict[str, Any]):
        """
        广播消息到所有连接的客户端
        :param message_data: 消息数据
        """
        if not self.clients:
            return
        
        message_json = json.dumps(message_data, ensure_ascii=False)
        disconnected_clients = []
        
        for client in self.clients:
            try:
                await client.send(message_json)
            except websockets.exceptions.ConnectionClosed:
                disconnected_clients.append(client)
            except Exception as e:
                self.logger.error(f"广播消息到客户端失败: {e}")
                disconnected_clients.append(client)
        
        # 移除断开的客户端
        for client in disconnected_clients:
            self.clients.discard(client)
    
    async def send_message(self, message_data: Dict[str, Any]):
        """
        发送消息（重写父类方法，用于广播）
        :param message_data: 消息数据
        """
        await self.broadcast_message(message_data)