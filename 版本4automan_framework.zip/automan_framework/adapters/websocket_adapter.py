"""
WebSocket适配器
用于对接支持WebSocket协议的消息平台，如QQ的LLOneBot
"""
import asyncio
import websockets
import json
import logging
from typing import Dict, Any, Optional
from .base_adapter import BaseAdapter


class WebSocketAdapter(BaseAdapter):
    """
    WebSocket适配器，用于对接支持WebSocket协议的消息平台
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        初始化WebSocket适配器
        :param config: 配置信息，包括WebSocket连接地址等
        """
        super().__init__(config)
        self.ws_url = config.get("ws_url", "ws://localhost:8080")
        self.websocket = None
        self.reconnect_interval = config.get("reconnect_interval", 5)
        self.logger = logging.getLogger(__name__)
        
    async def connect(self):
        """
        连接到WebSocket服务器
        """
        try:
            self.logger.info(f"正在连接到WebSocket服务器: {self.ws_url}")
            self.websocket = await asyncio.wait_for(websockets.connect(self.ws_url), timeout=5.0)
            self.is_running = True
            self.logger.info("WebSocket连接成功")
            
            # 启动消息接收循环
            asyncio.create_task(self._receive_loop())
            
        except asyncio.TimeoutError:
            self.logger.warning(f"WebSocket连接超时: {self.ws_url}，适配器将在后台继续尝试重连")
            # 即使连接失败也设置为运行状态，以便后台重连机制可以工作
            self.is_running = True
            # 启动重连任务
            asyncio.create_task(self._reconnect_task())
        except Exception as e:
            self.logger.error(f"WebSocket连接失败: {e}，适配器将在后台继续尝试重连")
            # 即使连接失败也设置为运行状态，以便后台重连机制可以工作
            self.is_running = True
            # 启动重连任务
            asyncio.create_task(self._reconnect_task())
    
    async def _reconnect_task(self):
        """
        重连任务
        """
        while self.is_running:
            await asyncio.sleep(self.reconnect_interval)
            if not self.websocket or self.websocket.closed:
                try:
                    self.logger.info(f"尝试重连到WebSocket服务器: {self.ws_url}")
                    self.websocket = await asyncio.wait_for(websockets.connect(self.ws_url), timeout=5.0)
                    self.logger.info("WebSocket重连成功")
                    # 重连成功后启动消息接收循环
                    asyncio.create_task(self._receive_loop())
                    break  # 成功连接后退出重连循环
                except Exception as e:
                    self.logger.error(f"WebSocket重连失败: {e}，将在{self.reconnect_interval}秒后重试")
    
    async def disconnect(self):
        """
        断开WebSocket连接
        """
        self.is_running = False
        if self.websocket:
            await self.websocket.close()
            self.logger.info("WebSocket连接已断开")
    
    async def send_message(self, message_data: Dict[str, Any]):
        """
        发送消息到WebSocket服务器
        :param message_data: 消息数据
        """
        if not self.websocket or not self.is_running or self.websocket.closed:
            self.logger.error("WebSocket未连接，无法发送消息")
            return False
        
        try:
            message_json = json.dumps(message_data, ensure_ascii=False)
            await self.websocket.send(message_json)
            self.logger.info(f"消息已发送: {message_data}")
            return True
        except Exception as e:
            self.logger.error(f"发送消息失败: {e}")
            # 尝试重连
            if self.websocket:
                try:
                    await self.websocket.close()
                except:
                    pass
            self.websocket = None
            return False
    
    def parse_message(self, raw_message: str) -> Dict[str, Any]:
        """
        解析WebSocket接收到的原始消息
        :param raw_message: 原始消息字符串
        :return: 标准化消息格式
        """
        try:
            data = json.loads(raw_message)
            
            # 标准化消息格式
            standardized_message = {
                "platform": "websocket",
                "message_id": data.get("message_id"),
                "user_id": str(data.get("user_id")),
                "group_id": data.get("group_id"),  # 可选
                "sender": data.get("sender", {}),
                "content": data.get("content", ""),
                "raw_data": data,
                "timestamp": data.get("time", asyncio.get_event_loop().time())
            }
            
            return standardized_message
        except json.JSONDecodeError as e:
            self.logger.error(f"解析消息失败: {e}, 原始消息: {raw_message}")
            return {
                "platform": "websocket",
                "error": f"解析消息失败: {e}",
                "raw_data": raw_message
            }
    
    async def _receive_loop(self):
        """
        消息接收循环
        """
        while self.is_running:
            try:
                if self.websocket and not self.websocket.closed:
                    message = await asyncio.wait_for(self.websocket.recv(), timeout=1.0)
                    parsed_message = self.parse_message(message)
                    
                    # 这里应该调用框架的消息处理逻辑
                    # 为简化，暂时只记录日志
                    self.logger.info(f"收到消息: {parsed_message}")
                    
            except asyncio.TimeoutError:
                # 超时是正常的，继续循环
                continue
            except websockets.exceptions.ConnectionClosed:
                self.logger.warning("WebSocket连接已关闭，尝试重连...")
                if self.is_running:
                    self.websocket = None
                    await asyncio.sleep(self.reconnect_interval)
                    try:
                        await self.connect()
                    except Exception as e:
                        self.logger.error(f"重连失败: {e}")
                        await asyncio.sleep(self.reconnect_interval)
            except Exception as e:
                self.logger.error(f"接收消息时发生错误: {e}")
                if self.is_running:
                    await asyncio.sleep(1)  # 避免错误时循环过快
    
    async def send_private_message(self, user_id: str, content: str):
        """
        发送私聊消息
        :param user_id: 用户ID
        :param content: 消息内容
        """
        message_data = {
            "action": "send_private_msg",
            "params": {
                "user_id": user_id,
                "message": content
            }
        }
        return await self.send_message(message_data)
    
    async def send_group_message(self, group_id: str, content: str):
        """
        发送群消息
        :param group_id: 群ID
        :param content: 消息内容
        """
        message_data = {
            "action": "send_group_msg",
            "params": {
                "group_id": group_id,
                "message": content
            }
        }
        return await self.send_message(message_data)