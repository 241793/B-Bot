import asyncio
import websockets
import json


async def simulate_llo_reverse_client():
    """
    模拟LLOneBot插件连接到反向WebSocket端口以接收消息
    """
    print("🤖 模拟LLOneBot反向连接客户端启动")
    print("这个客户端将连接到反向WebSocket服务器 (端口8085) 来接收Automan框架发送的消息")
    print("------------------------------------------------------------")
    
    try:
        async with websockets.connect('ws://127.0.0.1:8085') as websocket:
            print("✅ 成功连接到反向WebSocket服务器！现在可以接收Automan框架发送的消息。")
            
            # 保持连接并监听消息
            async for message in websocket:
                try:
                    data = json.loads(message)
                    print(f"📱 [{asyncio.get_event_loop().time()}] 收到框架消息: {data}")
                    
                    # 根据消息类型显示
                    action = data.get("action", "unknown")
                    params = data.get("params", {})
                    
                    if action == "send_group_msg":
                        print(f"👥 群聊消息 -> 群{params.get('group_id')}: {params.get('message')}")
                    elif action == "send_private_msg":
                        print(f"👤 私聊消息 -> 用户{params.get('user_id')}: {params.get('message')}")
                    else:
                        print(f"💬 未知消息类型: {data}")
                        
                except json.JSONDecodeError:
                    print(f"📄 收到文本消息: {message}")
                except Exception as e:
                    print(f"❌ 处理消息时出错: {e}")
                    
    except Exception as e:
        print(f"❌ 连接反向WebSocket服务器失败: {e}")


if __name__ == "__main__":
    asyncio.run(simulate_llo_reverse_client())