import asyncio
import websockets
import json


async def send_test_message():
    message = {
        "id": "test123",
        "type": "message",
        "content": "你好",
        "user_id": "qq_user_12345",
        "group_id": "qq_group_67890",
        "timestamp": "2025-12-26T14:35:00.000000",
        "raw_message": "你好"
    }
    
    try:
        async with websockets.connect('ws://localhost:8080') as websocket:
            await websocket.send(json.dumps(message, ensure_ascii=False))
            print("消息已发送: 你好")
            
            # 等待一段时间以查看响应
            await asyncio.sleep(3)
    except Exception as e:
        print(f"连接失败: {e}")


if __name__ == "__main__":
    asyncio.run(send_test_message())