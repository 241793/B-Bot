"""
全面测试脚本
测试Automan Framework的所有功能
"""
import asyncio
import websockets
import json
import uuid
from datetime import datetime
import requests
import time


async def test_websocket_functionality():
    """
    测试WebSocket功能
    """
    print("=== 测试WebSocket功能 ===")
    
    try:
        # 连接到WebSocket服务器
        async with websockets.connect("ws://localhost:8080") as websocket:
            print("✓ WebSocket连接成功")
            
            # 测试消息
            test_messages = [
                {"type": "message", "content": "你好", "user_id": "test_user_1", "id": str(uuid.uuid4())},
                {"type": "message", "content": "复读 测试WebSocket连接", "user_id": "test_user_1", "id": str(uuid.uuid4())},
                {"type": "message", "content": "测试插件功能", "user_id": "test_user_1", "id": str(uuid.uuid4())},
            ]
            
            for msg in test_messages:
                await websocket.send(json.dumps(msg, ensure_ascii=False))
                print(f"发送: {msg['content']}")
                
                # 等待响应
                response = await asyncio.wait_for(websocket.recv(), timeout=5.0)
                response_data = json.loads(response)
                print(f"接收: {response_data}")
                
                await asyncio.sleep(0.5)  # 稍微延迟
    
    except Exception as e:
        print(f"✗ WebSocket测试失败: {e}")
        return False
    
    print("✓ WebSocket功能测试完成\n")
    return True


def test_web_api():
    """
    测试Web API功能
    """
    print("=== 测试Web API功能 ===")
    
    base_url = "http://127.0.0.1:5000"
    
    try:
        # 测试状态API
        response = requests.get(f"{base_url}/api/status")
        if response.status_code == 200:
            status_data = response.json()
            print(f"✓ 状态API: {status_data}")
        else:
            print(f"✗ 状态API失败: {response.status_code}")
            return False
        
        # 测试插件API
        response = requests.get(f"{base_url}/api/plugins")
        if response.status_code == 200:
            plugins_data = response.json()
            print(f"✓ 插件API: 共{len(plugins_data)}个插件")
        else:
            print(f"✗ 插件API失败: {response.status_code}")
            return False
        
        # 测试规则API
        response = requests.get(f"{base_url}/api/rules")
        if response.status_code == 200:
            rules_data = response.json()
            print(f"✓ 规则API: 共{len(rules_data)}条规则")
        else:
            print(f"✗ 规则API失败: {response.status_code}")
            return False
        
        # 测试适配器API
        response = requests.get(f"{base_url}/api/adapters")
        if response.status_code == 200:
            adapters_data = response.json()
            print(f"✓ 适配器API: 共{len(adapters_data)}个适配器")
        else:
            print(f"✗ 适配器API失败: {response.status_code}")
            return False
        
        # 测试日志API
        response = requests.get(f"{base_url}/api/logs")
        if response.status_code == 200:
            logs_data = response.json()
            print(f"✓ 日志API: 共{len(logs_data)}条日志")
        else:
            print(f"✗ 日志API失败: {response.status_code}")
            return False
        
        # 测试添加规则API
        new_rule = {
            "name": "api_test_rule",
            "type": "keyword",
            "pattern": "api测试",
            "priority": 1,
            "description": "API测试规则"
        }
        response = requests.post(f"{base_url}/api/rules/add", json=new_rule)
        if response.status_code == 200:
            result = response.json()
            print(f"✓ 添加规则API: {result}")
        else:
            print(f"✗ 添加规则API失败: {response.status_code}")
            return False
        
        print("✓ Web API功能测试完成\n")
        return True
    
    except Exception as e:
        print(f"✗ Web API测试异常: {e}")
        return False


def test_plugin_management():
    """
    测试插件管理功能
    """
    print("=== 测试插件管理功能 ===")
    
    base_url = "http://127.0.0.1:5000"
    
    try:
        # 扫描插件
        response = requests.get(f"{base_url}/api/plugins/scan")
        if response.status_code == 200:
            plugins = response.json()
            print(f"✓ 扫描插件: {len(plugins)}个插件")
        else:
            print(f"✗ 扫描插件失败: {response.status_code}")
            return False
        
        # 创建新插件
        new_plugin = {
            "name": "test_management_plugin",
            "content": '''"""
测试管理插件
用于验证插件管理功能
"""

__description__ = "测试插件管理功能"
__version__ = "1.0.0"
__author__ = "Automan Framework"

rules = []

def handle_message(msg, middleware):
    return {"content": "插件管理功能测试响应"}

def unload():
    pass
'''
        }
        
        response = requests.post(f"{base_url}/api/plugins/create", json=new_plugin)
        if response.status_code == 200:
            result = response.json()
            print(f"✓ 创建插件: {result}")
        else:
            print(f"✗ 创建插件失败: {response.status_code}")
            return False
        
        # 获取插件内容
        response = requests.get(f"{base_url}/api/plugins/test_management_plugin/content")
        if response.status_code == 200:
            result = response.json()
            print(f"✓ 获取插件内容: 长度{len(result['content'])}字符")
        else:
            print(f"✗ 获取插件内容失败: {response.status_code}")
            return False
        
        print("✓ 插件管理功能测试完成\n")
        return True
    
    except Exception as e:
        print(f"✗ 插件管理测试异常: {e}")
        return False


async def run_comprehensive_test():
    """
    运行全面测试
    """
    print("开始运行Automan Framework全面测试...\n")
    
    success_count = 0
    total_tests = 3
    
    # 测试WebSocket功能
    if await test_websocket_functionality():
        success_count += 1
    
    # 稍等一下，确保系统状态稳定
    await asyncio.sleep(2)
    
    # 测试Web API
    if test_web_api():
        success_count += 1
    
    # 测试插件管理
    if test_plugin_management():
        success_count += 1
    
    print(f"\n=== 测试总结 ===")
    print(f"总测试数: {total_tests}")
    print(f"成功数: {success_count}")
    print(f"失败数: {total_tests - success_count}")
    
    if success_count == total_tests:
        print("🎉 所有测试均通过！Automan Framework运行正常！")
        return True
    else:
        print("❌ 部分测试失败，请检查框架配置。")
        return False


if __name__ == "__main__":
    try:
        asyncio.run(run_comprehensive_test())
    except KeyboardInterrupt:
        print("\n测试被用户中断")
    except Exception as e:
        print(f"\n测试运行异常: {e}")