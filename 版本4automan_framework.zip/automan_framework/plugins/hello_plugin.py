"""
示例插件 - 问候插件
展示如何编写Automan框架的插件
"""

__version__ = "1.0.0"
__author__ = "bucai Framework"
__description__ = "一个简单的问候插件"

import asyncio,time
from typing import Dict, Any
from datetime import datetime
from middleware.middleware import Middleware
async def hello_handler(message: Dict[str, Any], middleware) -> Dict[str, Any]:
    """
    处理问候消息
    """
    user_id = message.get("user_id", "unknown")
    response_content = f"你好！我是机器人助手66，收到了你的消息：{message.get('content', '')}"
    
    return {
        "content": response_content,
        "to_user_id": user_id
    }


async def echo_handler(message: Dict[str, Any], middleware) -> Dict[str, Any]:
    """
    处理复读消息
    """
    original_content = message.get("content", "")
    # 移除触发词"复读"
    response_content = original_content.replace("复读", "", 1).strip()
    
    return {
        "content": f"复读机: {response_content}",
    }
async def isadmin(message: Dict[str, Any], Middleware) -> Dict[str, Any]:
    """
    处理查询时间消息
    """
    id = message["user_id"]
    await Middleware.send_message("reverse_ws",id, "请输入用户id")
    user_reply = await Middleware.wait_for_input(message,timeout=12000)

    if user_reply:
        # 用户在10秒内回复了

        reply_content = user_reply
        print(reply_content)
        await Middleware.send_message("reverse_ws", id, f"输入了{reply_content}")
    else:
        # 用户超时未回复
        await Middleware.send_message("reverse_ws", id, "您好像没有回复，操作已取消。")

    a = await Middleware.is_admin(id)
    print(a)
    if a:
        return {
            "content": "你是管理员",
        }
    else:
        return {
            "content": "你不是管理员",
        }
async def tz(message: Dict[str, Any], Middleware):

    await Middleware.notify_admin("6666")

# 定义插件规则
rules = [
    {
        "name": "hello_rule",
        "pattern": r"^(你好|hello|hi|Hello)$",
        "handler": hello_handler,
        "rule_type": "regex",
        "priority": 10,
        "description": "匹配问候语并回应"
    },
    {
        "name": "echo_rule",
        "pattern": r"^通知",
        "handler": tz,
        "rule_type": "regex",
        "priority": 5,
        "description": "复读功能"
    },
    {
        "name": "查询时间",
        "pattern": r"^(我是不是管理员)$",
        "handler": isadmin,
        "rule_type": "regex",
        "priority": 10,
        "description": "匹配问候语并回应"
    },
]


def get_rules():
    """
    获取插件规则（备用方法）
    """
    return rules


def unload():
    """
    插件卸载时的清理工作
    """
    print("问候插件已卸载")