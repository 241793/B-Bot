"""
示例插件 - 问候插件
展示如何编写Automan框架的插件
"""

__version__ = "1.0.0"
__author__ = "Automan Framework"
__description__ = "一个简单的问候插件"

import asyncio
from typing import Dict, Any


async def hello_handler(message: Dict[str, Any], middleware) -> Dict[str, Any]:
    """
    处理问候消息
    """
    user_id = message.get("user_id", "unknown")
    response_content = f"你好！我是机器人助手，收到了你的消息：{message.get('content', '')}"
    
    return {
        "content": response_content,
        "to_user_id": user_id
    }


async def echo_handler(message: Dict[str, Any], middleware) -> Dict[str, Any]:
    """
    处理复读消息
    """
    original_content = message.get("content", "")
    # 移除触发词"复读"
    response_content = original_content.replace("复读", "", 1).strip()
    
    return {
        "content": f"复读机: {response_content}",
    }


# 定义插件规则
rules = [
    {
        "name": "hello_rule",
        "pattern": r"^(你好|hello|hi|Hello)$",
        "handler": hello_handler,
        "rule_type": "regex",
        "priority": 10,
        "description": "匹配问候语并回应"
    },
    {
        "name": "echo_rule",
        "pattern": r"^复读",
        "handler": echo_handler,
        "rule_type": "regex",
        "priority": 5,
        "description": "复读功能"
    }
]


def get_rules():
    """
    获取插件规则（备用方法）
    """
    return rules


def unload():
    """
    插件卸载时的清理工作
    """
    print("问候插件已卸载")