"""
测试插件
用于验证插件管理功能
"""

__description__ = "测试插件，用于验证插件管理功能"
__version__ = "1.0.0"
__author__ = "Automan Framework"

# 插件规则
rules = [
    {
        "name": "test_rule",
        "pattern": r"测试",
        "handler": lambda msg, mw: {"content": "这是测试插件的响应"},
        "rule_type": "keyword",
        "priority": 1,
        "description": "测试规则"
    }
]


def handle_message(msg, middleware):
    """
    处理消息的函数
    """
    print(f"测试插件处理消息: {msg}")
    return {"content": "测试插件响应"}


def unload():
    """
    插件卸载时的清理函数
    """
    print("测试插件正在卸载")