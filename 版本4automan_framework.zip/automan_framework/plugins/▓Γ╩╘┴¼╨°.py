
__description__ = "测试连续对话"

import asyncio
import re

from middleware.middleware import Middleware


async def test(message,Middleware):
    """
    测试连续对话
    """



    try:
        msg = message.get("content")
        if msg != "":

            if re.match("^在嘛$",msg):
                print(message)
                await Middleware.send_message(message.get("platform"), message["user_id"], "你在吗",msg=message)
                inp = await Middleware.wait_for_input(message,timeout=12000)

                if inp == "在":
                    return {"content": "玩游戏"}
                else:
                    return {"content": "鬼"}
    except Exception as e:
        print(e)



def register(middleware: Middleware):
    """
    当框架加载此插件时，会调用这个函数。
    """
    # 通过中间件注册你的消息处理器
    middleware.register_message_handler(test)
    print(f"示例插件 '{__description__}' 已加载并注册了消息处理器。")