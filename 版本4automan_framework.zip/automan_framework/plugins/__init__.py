"""
插件系统模块
包含插件加载、管理和执行功能
"""
import os
import importlib
import sys
import asyncio
import inspect
from typing import Dict, Any, List
from storage.bucket import BucketManager
from rule_engine.rule_engine import RuleEngine, Rule
from middleware.middleware import Middleware
from utils.logger import get_logger
from apscheduler.schedulers.background import BackgroundScheduler

class Plugin:
    """插件元数据类"""
    def __init__(self, name: str, module: Any, rules: List[Dict], is_loaded: bool = True):
        self.name = name
        self.module = module
        self.description = getattr(module, '__description__', '无描述') if module else '无描述'
        self.version = getattr(module, '__version__', '未知版本') if module else '未知版本'
        self.author = getattr(module, '__author__', '匿名作者') if module else '匿名作者'
        self.rules = rules
        self.is_loaded = is_loaded

class PluginManager:
    """插件管理器"""
    def __init__(self, plugins_dir: str, bucket_manager: BucketManager, rule_engine: RuleEngine, middleware: Middleware, scheduler: BackgroundScheduler):
        self.plugins_dir = plugins_dir
        self.bucket_manager = bucket_manager
        self.rule_engine = rule_engine
        self.middleware = middleware
        self.scheduler = scheduler
        self.plugins: Dict[str, Plugin] = {}
        self.logger = get_logger("plugin_manager")

        if plugins_dir not in sys.path:
            sys.path.insert(0, plugins_dir)

        self.disabled_plugins_bucket = self.bucket_manager.get_sync('plugin_manager', 'disabled_plugins', default=[])

    async def load_all_plugins(self):
        """加载所有未被禁用的插件"""
        self.logger.info("开始加载所有插件...")
        tasks = []
        for filename in os.listdir(self.plugins_dir):
            if filename.endswith(".py") and not filename.startswith("__"):
                plugin_name = filename[:-3]
                if plugin_name in self.disabled_plugins_bucket:
                    self.logger.info(f"插件 {plugin_name} 已被禁用，跳过加载。")
                    continue
                tasks.append(self.load_plugin(plugin_name))
        await asyncio.gather(*tasks)
        self.logger.info("所有插件加载完毕。")

    async def load_plugin(self, name: str) -> bool:
        """加载单个插件"""
        if name in self.plugins and self.plugins[name].is_loaded:
            self.logger.warning(f"插件 {name} 已经加载。")
            return True

        try:
            module_name = name
            if module_name in sys.modules:
                module = importlib.reload(sys.modules[module_name])
            else:
                module = importlib.import_module(module_name)

            # 注册基于 register 函数的处理器
            if hasattr(module, 'register') and callable(getattr(module, 'register')):
                register_func = getattr(module, 'register')
                sig = inspect.signature(register_func)
                num_params = len(sig.parameters)

                if num_params == 1:
                    register_func(self.middleware)
                elif num_params == 2:
                    register_func(self.middleware, self.scheduler)
                else:
                    self.logger.warning(f"插件 {name} 的 register 函数有 {num_params} 个参数，无法确定如何调用。")

                self.logger.info(f"为插件 {name} 调用了 register 函数。")

            rules = getattr(module, 'rules', [])
            self.plugins[name] = Plugin(name, module, rules)
            await self._register_plugin_rules(name)

            self.logger.info(f"插件 {name} 加载成功。")
            return True
        except Exception as e:
            self.logger.error(f"加载插件 {name} 失败: {e}", exc_info=True)
            return False

    async def unload_plugin(self, name: str) -> bool:
        """卸载单个插件"""
        if name not in self.plugins or not self.plugins[name].is_loaded:
            self.logger.warning(f"插件 {name} 未加载或已卸载。")
            return True

        try:
            plugin = self.plugins[name]

            if hasattr(plugin.module, 'unload'):
                unload_func = getattr(plugin.module, 'unload')
                sig = inspect.signature(unload_func)
                num_params = len(sig.parameters)

                if num_params == 0:
                    unload_func()
                elif num_params == 1:
                    unload_func(self.scheduler)
                else:
                    self.logger.warning(f"插件 {name} 的 unload 函数有 {num_params} 个参数，无法确定如何调用。")


            await self._unregister_plugin_rules(name)

            if name in sys.modules:
                del sys.modules[name]

            self.plugins[name].is_loaded = False
            del self.plugins[name]

            self.logger.info(f"插件 {name} 卸载成功。")
            return True
        except Exception as e:
            self.logger.error(f"卸载插件 {name} 失败: {e}", exc_info=True)
            return False

    async def reload_plugin(self, name: str) -> bool:
        """重新加载插件"""
        self.logger.info(f"正在重载插件 {name}...")
        if await self.unload_plugin(name):
            return await self.load_plugin(name)
        return False

    async def enable_plugin(self, name: str):
        """启用插件"""
        if name in self.disabled_plugins_bucket:
            self.disabled_plugins_bucket.remove(name)
            await self.bucket_manager.set('plugin_manager', 'disabled_plugins', self.disabled_plugins_bucket)
            self.logger.info(f"插件 {name} 已从禁用列表移除。")
            return await self.load_plugin(name)
        self.logger.warning(f"插件 {name} 未被禁用。")
        return True

    async def disable_plugin(self, name: str):
        """禁用插件"""
        if name not in self.disabled_plugins_bucket:
            self.disabled_plugins_bucket.append(name)
            await self.bucket_manager.set('plugin_manager', 'disabled_plugins', self.disabled_plugins_bucket)
            self.logger.info(f"插件 {name} 已添加到禁用列表。")
            return await self.unload_plugin(name)
        self.logger.warning(f"插件 {name} 已在禁用列表中。")
        return True

    def get_all_plugins(self) -> Dict[str, Plugin]:
        """获取所有已发现的插件"""
        all_plugins_on_disk = {}
        for filename in os.listdir(self.plugins_dir):
            if filename.endswith(".py") and not filename.startswith("__"):
                plugin_name = filename[:-3]
                if plugin_name in self.plugins:
                    all_plugins_on_disk[plugin_name] = self.plugins[plugin_name]
                else:
                    all_plugins_on_disk[plugin_name] = Plugin(plugin_name, None, [], is_loaded=False)
        return all_plugins_on_disk

    def get_plugin(self, name: str) -> Plugin:
        return self.plugins.get(name)

    def is_plugin_enabled(self, name: str) -> bool:
        return name not in self.disabled_plugins_bucket

    async def _register_plugin_rules(self, plugin_name: str):
        """注册插件的规则"""
        plugin = self.plugins.get(plugin_name)
        if not plugin or not plugin.is_loaded:
            return
            
        for rule_dict in plugin.rules:
            rule_name = f"{plugin_name}.{rule_dict['name']}"
            rule = Rule(
                name=rule_name,
                pattern=rule_dict["pattern"],
                handler=rule_dict["handler"],
                rule_type=rule_dict.get("rule_type", "regex"),
                priority=rule_dict.get("priority", 0),
                description=rule_dict.get("description", ""),
                source='plugin'
            )
            await self.rule_engine.add_rule(rule)
        self.logger.debug(f"为插件 {plugin_name} 注册了 {len(plugin.rules)} 条规则。")

    async def _unregister_plugin_rules(self, plugin_name: str):
        """注销插件的规则"""
        rules_to_remove = [rule for rule in self.rule_engine.rules if rule.name.startswith(f"{plugin_name}.")]
        tasks = [self.rule_engine.remove_rule(rule.name) for rule in rules_to_remove]
        await asyncio.gather(*tasks)
        self.logger.debug(f"为插件 {plugin_name} 注销了 {len(rules_to_remove)} 条规则。")