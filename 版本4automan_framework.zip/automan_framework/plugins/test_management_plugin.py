"""
测试管理插件
用于验证插件管理功能
"""

__description__ = "测试插件管理功能"
__version__ = "1.0.0"
__author__ = "Automan Framework"

rules = []

def handle_message(msg, middleware):
    return {"content": "插件管理功能测试响应"}

def unload():
    pass
