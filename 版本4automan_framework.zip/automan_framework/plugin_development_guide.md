# 插件开发指南

本文档旨在帮助开发者了解如何在 `automan_framework` 中创建和开发插件。插件是扩展机器人功能的核心。

## 1. 插件基础

插件本质上是一个遵循特定规范的 Python 模块，框架会自动加载并运行它。

- **位置**: 所有插件都应放置在 `plugins/` 目录下。
- **入口**: 框架会寻找并执行插件模块中的 `register` 函数来初始化插件。

一个最简单的插件结构如下：

```python
# /plugins/my_awesome_plugin.py

# 导入必要的类型
from middleware.middleware import Middleware

# 插件的主体功能
async def my_message_handler(message: dict):
    """
    这是一个消息处理器，它会接收所有通过框架的消息。
    """
    content = message.get("content", "").strip()
    if content == "你好":
        # 当收到“你好”时，返回一个响应字典
        return {"content": "你好！我是你的机器人助手。"}
    # 如果不处理此消息，则不返回任何内容
    return None

# 插件注册函数（必需）
def register(middleware: Middleware):
    """
    当框架加载此插件时，会调用这个函数。
    """
    # 通过中间件注册你的消息处理器
    middleware.register_message_handler(my_message_handler)
    print("示例插件 'my_awesome_plugin' 已加载并注册了消息处理器。")

```

## 2. 如何使用 Middleware 功能

`Middleware` 对象是插件与框架交互的唯一桥梁。当框架调用你的 `register` 函数时，会将一个 `Middleware` 实例作为参数传递给你。你应该将其保存下来，以便在插件的其他地方使用。

虽然在上面的简单示例中我们只在 `register` 函数里用了一次 `middleware`，但更复杂的插件可能需要在多个地方调用它。你可以将它保存在一个类或者全局变量中。

### 2.1 接收和响应消息

最常见的插件功能是响应用户的消息。

- **注册处理器**: 使用 `middleware.register_message_handler(your_handler_function)` 来监听所有消息。
- **处理消息**: 你的处理器函数会收到一个 `message` 字典，它包含了消息的所有信息（如内容、发送者ID、群组ID等）。
- **快速响应**: 如果你的处理器函数返回一个包含 `content` 键的字典，框架会自动将该 `content` 作为回复发送到消息的来源地（私聊或群聊）。这是最简单的响应方式。

```python
# /plugins/echo_plugin.py
from middleware.middleware import Middleware

async def echo_handler(message: dict):
    response_content = f"你刚才说的是：{message.get('content')}"
    return {"content": response_content}

def register(middleware: Middleware):
    middleware.register_message_handler(echo_handler)
```

### 2.2 主动发送消息

除了被动响应，插件也可以主动向任何地方发送消息。

- **函数**: `await middleware.send_message(platform, target_id, content)`
- **参数**:
    - `platform`: 平台名称 (例如: `'qq'`, `'websocket'`)。
    - `target_id`: 目标ID。对于私聊，是用户ID；对于群聊，是群ID。
    - `content`: 你想发送的消息内容。

**示例：一个定时提醒插件**

```python
# /plugins/reminder_plugin.py
import asyncio
from middleware.middleware import Middleware

class ReminderPlugin:
    def __init__(self, middleware: Middleware):
        self.middleware = middleware
        self.reminders = {}

    async def add_reminder_handler(self, message: dict):
        content = message.get("content", "")
        parts = content.split()
        if content.startswith("!提醒我"):
            try:
                seconds = int(parts[1])
                reminder_text = " ".join(parts[2:])
                user_id = message["user_id"]
                
                # 安排一个定时任务
                asyncio.create_task(self.schedule_reminder(seconds, user_id, reminder_text, message["platform"]))
                
                return {"content": f"好的，我会在 {seconds} 秒后提醒你。"}
            except (IndexError, ValueError):
                return {"content": "格式错误！请使用：!提醒我 [秒数] [提醒内容]"}

    async def schedule_reminder(self, delay, user_id, text, platform):
        await asyncio.sleep(delay)
        # 使用 send_message 主动发送消息
        await self.middleware.send_message(
            platform=platform,
            target_id=user_id,
            content=f"提醒时间到！\n提醒内容：{text}"
        )

def register(middleware: Middleware):
    plugin = ReminderPlugin(middleware)
    middleware.register_message_handler(plugin.add_reminder_handler)
    print("提醒插件已加载。")
```

### 2.3 使用持久化存储 (Bucket)

插件经常需要存储数据，例如用户配置、游戏得分等。`Middleware` 提供了基于 "Bucket" 的简单键值存储。

- **概念**: Bucket 是一个数据容器，类似于一个字典。每个插件可以拥有一个或多个独立的 Bucket。
- **函数**:
    - `await middleware.bucket_set(bucket_name, key, value)`: 保存数据。
    - `await middleware.bucket_get(bucket_name, key, default=None)`: 读取数据。
    - `await middleware.bucket_delete(bucket_name, key)`: 删除一个键。
    - `await middleware.bucket_keys(bucket_name)`: 获取所有键。

**示例：一个计数器插件**

```python
# /plugins/counter_plugin.py
from middleware.middleware import Middleware

BUCKET_NAME = "counter_plugin_data"

async def counter_handler(message: dict):
    user_id = message["user_id"]
    
    # 从 bucket 中读取用户发言次数
    current_count = await middleware.bucket_get(BUCKET_NAME, user_id, default=0)
    
    # 次数加一并存回
    new_count = current_count + 1
    await middleware.bucket_set(BUCKET_NAME, user_id, new_count)
    
    if new_count % 10 == 0:
        return {"content": f"恭喜！你已经在这个机器人面前发言 {new_count} 次了！"}

def register(m: Middleware):
    global middleware
    middleware = m
    middleware.register_message_handler(counter_handler)
    print("计数器插件已加载。")
```

### 2.4 管理员权限

你可以使用 `middleware` 来检查一个用户是否是管理员，从而创建只有管理员才能使用的命令。

- `middleware.is_admin(user_id)`: 返回 `True` 或 `False`。

**示例：一个只能由管理员使用的插件**

```python
# /plugins/admin_only_plugin.py
from middleware.middleware import Middleware

async def admin_command_handler(message: dict):
    content = message.get("content", "")
    user_id = message["user_id"]
    
    if content == "!shutdown" and middleware.is_admin(user_id):
        # 这里只是示例，实际的关机逻辑会更复杂
        return {"content": "机器人正在关闭... (仅为演示)"}
    elif content == "!shutdown" and not middleware.is_admin(user_id):
        return {"content": "抱歉，你没有权限执行此操作。"}

def register(m: Middleware):
    global middleware
    middleware = m
    middleware.register_message_handler(admin_command_handler)
    print("管理员插件已加载。")
```

## 3. 总结

通过 `middleware` 对象，插件可以实现强大而丰富的功能：
1.  **创建 `register` 函数**作为插件入口。
2.  在 `register` 函数中获取 `Middleware` 实例。
3.  调用 `middleware.register_message_handler()` 来**监听消息**。
4.  在消息处理器中，通过返回字典来**快速响应**，或使用 `middleware.send_message()` **主动发送**。
5.  使用 `middleware.bucket_*` 函数来**存储和读取数据**。
6.  使用 `middleware.is_admin()` 来实现**权限控制**。

遵循以上模式，你就可以开始构建你自己的插件了！
