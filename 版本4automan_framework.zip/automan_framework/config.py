"""
配置文件
定义框架的全局配置
"""
import os
from typing import Dict, Any


class Config:
    """
    配置类
    """
    # 为计划任务定义数据库路径
    _data_dir = os.getenv('DATA_DIR', 'data')
    DATABASE_URL = f"sqlite:///{os.path.join(_data_dir, 'jobs.db')}"

    def __init__(self):
        # 基本配置
        self.debug = os.getenv('DEBUG', 'False').lower() == 'true'
        self.host = os.getenv('HOST', '0.0.0.0')
        self.port = int(os.getenv('PORT', '8080'))
        
        # WebSocket适配器配置
        self.ws_url = os.getenv('WS_URL', '')  # 默认为空，不自动连接
        self.reconnect_interval = int(os.getenv('RECONNECT_INTERVAL', '5'))
        
        # 存储配置
        self.data_dir = self._data_dir
        
        # Web UI配置
        self.web_ui_host = os.getenv('WEB_UI_HOST', '0.0.0.0')
        self.web_ui_port = int(os.getenv('WEB_UI_PORT', '8080'))
        
        # 反向WebSocket配置 (LLOneBot反向连接端口)
        self.reverse_ws_host = os.getenv('REVERSE_WS_HOST', '0.0.0.0')
        self.reverse_ws_port = int(os.getenv('REVERSE_WS_PORT', '8085'))
        
        # 插件配置
        self.plugins_dir = os.getenv('PLUGINS_DIR', 'plugins')
        
        # 日志配置
        self.log_level = os.getenv('LOG_LEVEL', 'INFO')
        self.log_dir = os.getenv('LOG_DIR', 'logs')
        
        # 默认管理员
        self.admin_users = os.getenv('ADMIN_USERS', '').split(',') if os.getenv('ADMIN_USERS') else []
    
    def to_dict(self) -> Dict[str, Any]:
        """
        转换为字典格式
        """
        return {
            'debug': self.debug,
            'host': self.host,
            'port': self.port,
            'ws_url': self.ws_url,
            'reconnect_interval': self.reconnect_interval,
            'data_dir': self.data_dir,
            'web_ui_host': self.web_ui_host,
            'web_ui_port': self.web_ui_port,
            'plugins_dir': self.plugins_dir,
            'log_level': self.log_level,
            'log_dir': self.log_dir,
            'admin_users': self.admin_users
        }


# 创建全局配置实例
config = Config()